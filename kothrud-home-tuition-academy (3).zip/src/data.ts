export interface CourseCard {
  id: string;
  title: string;
  description: string;
  targetAges: string;
  category: 'academic' | 'skill';
  highlights: string[];
}

export interface Testimonial {
  id: string;
  parentName: string;
  studentName: string;
  standard: string;
  school: string;
  review: string;
  result: string;
  rating: number;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface SellingPoint {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface MethodologyStep {
  stepNumber: string;
  title: string;
  description: string;
}

export const SELLING_POINTS: SellingPoint[] = [
  {
    id: 'exp',
    title: '20+ Years Experience',
    description: 'Expert, highly trusted, and experienced educators who understand diverse child mentalities and curriculum demands.',
    iconName: 'Award',
  },
  {
    id: 'one-to-one',
    title: 'One-to-One Home Tuition',
    description: 'Personalized attention in the comfort and safety of your home. Customized pace for quick learning.',
    iconName: 'UserCheck',
  },
  {
    id: 'small-batches',
    title: 'Small Batch Classes',
    description: 'Strict batch size limits at our Bhusari Colony center to maintain exceptional teacher-student interaction.',
    iconName: 'Users',
  },
  {
    id: 'affordable',
    title: 'Affordable Fees',
    description: 'Highest quality home and batch learning provided at reasonable, budget-friendly structures with flexible terms.',
    iconName: 'IndianRupee',
  },
  {
    id: 'proven-results',
    title: 'Proven Academic Improvement',
    description: 'Over 92% of our pupils see a significant leap in scores, reading confidence, and conceptual grasp within 3 months.',
    iconName: 'TrendingUp',
  },
  {
    id: 'tracking',
    title: 'Regular Progress Tracking',
    description: 'Bi-weekly tests, comprehensive feedback, and parent-teacher alignment meetings keeping you informed.',
    iconName: 'CalendarCheck',
  },
  {
    id: 'modern-tech',
    title: 'Modern Learning Techniques',
    description: 'Visual aids, interactive storytelling, brain games, and conceptual assignments rather than rote memorization.',
    iconName: 'Sparkles',
  },
  {
    id: 'areas',
    title: 'Kothrud & Nearby Coverage',
    description: 'Tuition available across Bhusari Colony, Karve Nagar, Bavdhan, Warje, and other key areas of Pune, Maharashtra.',
    iconName: 'MapPin',
  },
];

export const ACADEMIC_COURSES: CourseCard[] = [
  {
    id: 'kindergarten',
    title: 'Early Years Foundation (Nursery & KG)',
    description: 'Play-way interactive system designed for child-friendly induction into reading, basic numbers, shapes, and communication.',
    targetAges: 'Nursery, Junior KG, Senior KG',
    category: 'academic',
    highlights: ['Phonics Basics', 'Motor Activity Learning', 'English Speaking Prep', 'Reading Skills'],
  },
  {
    id: 'primary-school',
    title: 'Primary Wing (1st to 4th Standard)',
    description: 'Strong foundation in core academic courses building numerical competency, neat handwriting, and active thinking from grade 1.',
    targetAges: '1st Standard, 2nd Standard, 3rd Standard, 4th Standard',
    category: 'academic',
    highlights: ['Mathematics & EVS', 'Marathi & English Grammar', 'Hindi Medium Assistance', 'Creative Activity Drills'],
  },
  {
    id: 'middle-school',
    title: 'Middle School Excellence (5th to 8th Standard)',
    description: 'Rigorous interactive guidance focusing on concept-building, critical reasoning, science experiments, and exam writing frameworks.',
    targetAges: '5th Standard, 6th Standard, 7th Standard, 8th Standard',
    category: 'academic',
    highlights: ['Advanced Math & Science', 'Hindi & Marathi Writing', 'Social Studies & History', 'Spoken English Practice'],
  },
];

export const SKILL_PROGRAMS: CourseCard[] = [
  {
    id: 'phonics-training',
    title: 'Interactive Phonics Training',
    description: 'Improve English reading and pronunciation by teaching letter-sound correspondences, decoding, and word blending.',
    targetAges: 'Ages 4 to 9 Years',
    category: 'skill',
    highlights: ['Pronunciation Mastery', 'Fluid Comprehension', 'Self-corrections', 'Vocabulary Development'],
  },
  {
    id: 'handwriting-improvement',
    title: 'Handwriting Excellence',
    description: 'Special school-readiness course focusing on cursive flow, letter spacing, posture, pen grip, and uniform alignment.',
    targetAges: 'All standard pupils',
    category: 'skill',
    highlights: ['Cursive & Block Script', 'Correct Pen Grip Technique', 'Speed & Elegance Boost', 'Custom Copybook Drills'],
  },
  {
    id: 'spoken-english-personality',
    title: 'Spoken English & Personality',
    description: 'Enhances confidence, public speaking capacity, daily conversations, vocabulary range, and active stage presence.',
    targetAges: 'Ages 5 to 14 Years',
    category: 'skill',
    highlights: ['Debate & Stage Confidence', 'Voice Modulation', 'Daily Dialog Practice', 'Social Mannerism Prep'],
  },
  {
    id: 'drawing-classes',
    title: 'Creative Sketching & Drawing',
    description: 'Guided artistic training focusing on basic shapes, proportions, pastel coloring, sketch pens, and pencil shading.',
    targetAges: 'Kindergarten to Class 8',
    category: 'skill',
    highlights: ['Color Therapy & Warmth', 'Geometry and Layout', 'Watercolors Induction', 'Portfolio Creation'],
  },
  {
    id: 'coding-computer',
    title: 'Computer Basics & Coding Fundamentals',
    description: 'Basic keyboard mastery, digital literacy, and graphical coding platforms designed for logical skill enhancement.',
    targetAges: 'Class 3 to 8 Standard',
    category: 'skill',
    highlights: ['Scratch & Blockly Logic', 'Computer Fundamentals', 'Safe Internet Guidelines', 'Logical Algorithms'],
  },
  {
    id: 'creative-activities',
    title: 'Creative Learning & Enhancement',
    description: 'Fun, off-screen cognitive workshops focusing on logical puzzles, active brain coordination, and reading skills development.',
    targetAges: 'Ages 4 to 12 Years',
    category: 'skill',
    highlights: ['Aptitude Riddles', 'Mental Arithmetic Prep', 'Rapid Reading Speed', 'Memory Retention Hacks'],
  },
];

export const METHODOLOGY_STEPS: MethodologyStep[] = [
  {
    stepNumber: '01',
    title: 'Student Assessment',
    description: 'We run a initial evaluation to identify current conceptual gaps, core strengths, personal learning speed, and confidence level.',
  },
  {
    stepNumber: '02',
    title: 'Customized Study Plan',
    description: 'A tailored academic path is drafted by combining school syllabus targets, weak areas, and targeted visual teaching aids.',
  },
  {
    stepNumber: '03',
    title: 'Interactive Teaching',
    description: 'Concepts are cleared using child-friendly examples, real-life applications, drawing, and customized assignments.',
  },
  {
    stepNumber: '04',
    title: 'Regular Practice',
    description: 'Structured homework tracking, recurring worksheets, and immediate corrections to reinforce the topics taught.',
  },
  {
    stepNumber: '05',
    title: 'Weekly Progress Tracking',
    description: 'Bi-weekly concept tests, milestone report cards, and phone reviews to align parents with measurable outcomes.',
  },
  {
    stepNumber: '06',
    title: 'Performance Improvement',
    description: 'Watch your child thrive physically and academically with improved school scores, pristine handwriting, and high communication self-belief.',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    parentName: 'Mrs. Smita Kulkarni',
    studentName: 'Advait',
    standard: '4th Standard (ICSE)',
    school: 'Abhinava Vidyalaya, Kothrud',
    review: 'Our son shifted from Marathi medium prep to an ICSE school. He struggled heavily with English phonics and math logic. Within 4 months of home tuition from Kothrud Tuition Academy, he topped his spell-bee contest and scored an amazing 96% in his term exams! Highly professional and absolutely child-friendly teaching.',
    result: '96% in Mathematics & English',
    rating: 5,
  },
  {
    id: 't2',
    parentName: 'Mr. Rohan Deshpande',
    studentName: 'Isha',
    standard: '7th Standard (CBSE)',
    school: 'Sanskriti School, Bhusari Colony',
    review: 'We were highly concerned about her handwriting and social hesitation. The custom handwriting drills and spoken English mentoring completely transformed her personality! She now confidently hosts school events, and her handwriting legibility has improved immensely.',
    result: 'Best Handwriting Award in Class',
    rating: 5,
  },
  {
    id: 't3',
    parentName: 'Mrs. Pranjal Joshi',
    studentName: 'Siddharth',
    standard: '1st Standard',
    school: 'Millennium National School, Karve Nagar',
    review: 'Finding an experienced teacher near Bhusari Colony who handles energetic 6-year-olds with patience was tough. The one-to-one tutoring is a godsend. Siddharth looks forward to his math activities and drawing session every single day!',
    result: 'A+ in Numerical Aptitude Tests',
    rating: 5,
  },
];

export const FAQS: FAQItem[] = [
  {
    question: 'What is the best home tuition in Kothrud Pune?',
    answer: 'Kothrud Home Tuition Academy in Bhusari Colony is widely rated as the premier provider of personalized tuition due to our 20+ years of teaching experience, committed one-to-one home teachers, professional standard-wise curriculum, and highly-experienced local Pune mentors who target both state board (SSC), CBSE, and ICSE structures.',
  },
  {
    question: 'Do you provide one-to-one home tuition?',
    answer: 'Yes! We specialize in premium, high-trust, one-to-one home tuition where an experienced local Bhusari Colony/Kothrud home tutor visits your residence to deliver focused, customized instruction at your child’s absolute learning pace.',
  },
  {
    question: 'What subjects do you teach?',
    answer: 'We provide full academic instruction across all standards (Nursery to 8th) covering Mathematics, Science, English, Marathi, Hindi, Social Studies, EVS, Grammar, Reading Skills, and Writing Skills.',
  },
  {
    question: 'Do you teach phonics and handwriting improvement?',
    answer: 'Absolutely! Our skill-building specialized modules include Phonics Training (for young primary readers to master spelling and pronunciation) and our highly-sought Handwriting Improvement classes focusing on proper pencil grip, letter styling, and speed.',
  },
  {
    question: 'Are batch classes available at physical centers?',
    answer: 'Yes, we offer micro-batch classes (strictly limited headcounts) at our head academy located at Bhusari Colony, Kothrud, Pune. This ensures affordability while retaining personal focus.',
  },
  {
    question: 'What are the fees for home tuition vs batch classes?',
    answer: 'Our fee structure is extremely competitive and depends on your child’s standard (Nursery to 8th), the mode (personalized home tutor vs. micro-batch), and subjects needed. Get in touch with us on WhatsApp for an instant custom quote aligned with your exact preferences!',
  },
  {
    question: 'Do you offer trial/demo classes?',
    answer: 'Yes, we provide 100% Free Demo Classes to ensure perfect chemistry and comfort between our teacher and your child before you proceed with the enrollment.',
  },
  {
    question: 'Do you cover nearby areas around Bhusari Colony, Kothrud?',
    answer: 'Yes, our home tutors actively travel across all prominent neighborhoods in Pune including Bhusari Colony, Kothrud Depo, Karve Nagar, Bavdhan, Warje, Anand Nagar, and Paud Road. Feel free to enquire is your locality is covered!',
  },
];
