import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Volume2, 
  PenTool, 
  Compass, 
  BrainCircuit, 
  Sparkles, 
  Check, 
  Phone, 
  HelpCircle, 
  Upload, 
  BookOpen, 
  CheckCircle, 
  RefreshCw,
  Award,
  ArrowRight
} from 'lucide-react';

// Phonic cards lookup
interface PhonicBlend {
  blend: string;
  exampleWords: string[];
  audioCue: string;
  tongueCue: string;
  recommendedAge: string;
}

const PHONICS_DATA: PhonicBlend[] = [
  {
    blend: "sh",
    exampleWords: ["Ship", "Shop", "Wish", "Brush", "Shine"],
    audioCue: "shuh as in ship. Soft blowing air sound.",
    tongueCue: "Press the sides of your tongue against your upper molars. Blow out air softly through the narrow center channel.",
    recommendedAge: "Ages 4-6"
  },
  {
    blend: "ch",
    exampleWords: ["Chair", "Chime", "Munch", "Branch", "Catch"],
    audioCue: "chuh as in chair. Sharp clicking air sound.",
    tongueCue: "Place tip of tongue firm on the roof of mouth, then release suddenly with a sharp puff of air.",
    recommendedAge: "Ages 4-6"
  },
  {
    blend: "th",
    exampleWords: ["Think", "Thin", "Bath", "Cloth", "Mother"],
    audioCue: "thuh as in think. Soft feather-touch air sound.",
    tongueCue: "Place the tip of your tongue gently between your front teeth. Blow air softly over the tongue.",
    recommendedAge: "Ages 5-7"
  },
  {
    blend: "ee",
    exampleWords: ["Sleep", "Tree", "Queen", "Green", "Sweet"],
    audioCue: "ee as in tree. Smiling long vowel sound.",
    tongueCue: "Spread your lips wide like you are smiling. Keep your tongue high and forward in the mouth.",
    recommendedAge: "Ages 4-6"
  },
  {
    blend: "ai",
    exampleWords: ["Rain", "Train", "Nail", "Snail", "Paint"],
    audioCue: "ay as in train. High sliding long sound.",
    tongueCue: "Open mouth partially, tongue resting behind bottom teeth, sliding from flat to a high front smile posture.",
    recommendedAge: "Ages 5-7"
  },
  {
    blend: "oo",
    exampleWords: ["Book", "Spoon", "Wood", "Foot", "Moon"],
    audioCue: "ooh as in spoon. Rounded mouth vowel sound.",
    tongueCue: "Pucker your lips closely together into a circular shape. Keep back of tongue elevated.",
    recommendedAge: "Ages 4-6"
  },
  {
    blend: "oy",
    exampleWords: ["Toy", "Boy", "Joy", "Soil", "Coy"],
    audioCue: "oy as in toy. Double sliding dynamic sound.",
    tongueCue: "Start with mouth circular and rounded, slide smoothly into a smiling wide lips posture.",
    recommendedAge: "Ages 5-8"
  },
  {
    blend: "ow",
    exampleWords: ["Cow", "Town", "Brown", "Howl", "Glow"],
    audioCue: "ow as in cow. Wide to narrow slide sound.",
    tongueCue: "Start with open low tongue, then raise the back of tongue while curling lips tight into a circle.",
    recommendedAge: "Ages 5-8"
  }
];

// Syllabus data
interface SyllabusRoadmap {
  speedTarget: string;
  keyConcepts: string[];
  weeklyPracticeLimit: string;
  milestones: string[];
}

const SYLLABUS_ROADMAPS: Record<string, SyllabusRoadmap> = {
  "nursery-CBSE": {
    speedTarget: "Motor grip work (Drawing straight & wavy lines)",
    keyConcepts: ["A to Z phonics traces", "Numbers 1-10 visual objects", "Color naming & basic patterns", "English speech starters"],
    weeklyPracticeLimit: "2 practice sheets per week",
    milestones: ["Hold pencil with absolute safety pinch", "Identify active vowel starters", "Sort basic solid shapes"]
  },
  "nursery-ICSE": {
    speedTarget: "Tracing letter arcs & pencil balance",
    keyConcepts: ["A to Z visual identification", "Numbers 1-20 sequence", "Primary color sketching", "Sentence greetings matching"],
    weeklyPracticeLimit: "3 interactive sheets per week",
    milestones: ["Match identical shapes", "Trace alphabetic stems", "Verbally recite 5 nursery rhymes"]
  },
  "nursery-SSC": {
    speedTarget: "Crayon circle bounding & wrist control",
    keyConcepts: ["English alphabet visualizer", "Basic count till 10", "Marathi numbers visual introduction", "Nursery games"],
    weeklyPracticeLimit: "2 simplified playbooks",
    milestones: ["Identify primary coloring", "Recognize body parts", "Answer basic self-initiation queries"]
  },
  "primary-CBSE": {
    speedTarget: "Writing speed target: 12-15 Words Per Minute",
    keyConcepts: ["Mathematical addition & subtraction word problems", "EVS Plants, habitat systems", "English nouns & active verbs", "Marathi medium basic letters"],
    weeklyPracticeLimit: "4 practice concept logs per week",
    milestones: ["Draw accurate metric charts", "Perform 2-digit calculations without finger counts", "Read basic 50-word passages fluently"]
  },
  "primary-ICSE": {
    speedTarget: "Writing speed target: 15-18 Words Per Minute (High Cursive cursive focus)",
    keyConcepts: ["Geometry shapes & fractions logic", "General Science animal skeletons, light foundations", "ICSE English interactive readbook, pronouns", "Daily cursive flow diaries"],
    weeklyPracticeLimit: "5 advanced printable worksheets per week",
    milestones: ["Write complete cursive stories neatly", "Analyze standard science life cycles", "Understand primary fractions visually"]
  },
  "primary-SSC": {
    speedTarget: "Writing speed target: 10-12 Words Per Minute (Neat alignment focus)",
    keyConcepts: ["Class math tables up to 15", "Primary science water cycles", "Standard grammar spelling", "Marathi & Hindi medium language poems"],
    weeklyPracticeLimit: "3 structured test drafts",
    milestones: ["Recite standard schedules confidently", "Demonstrate clean baseline alignment with pen", "Read primary Marathi script fluently"]
  },
  "middle-CBSE": {
    speedTarget: "Writing speed target: 20-22 Words Per Minute (Detailed answers)",
    keyConcepts: ["Algebra basic variables & linear equations", "Physics Forces, friction, cell structures", "English grammar active/passive voice, direct speech", "Sanskrit or Hindi poetry analysis"],
    weeklyPracticeLimit: "5 rigorous test sheets",
    milestones: ["Solve multi-step math theorems", "Draft complete 150-word essays with neat titles", "Explain complex science experiments accurately"]
  },
  "middle-ICSE": {
    speedTarget: "Writing speed target: 22-25 Words Per Minute (High speed exam tracking)",
    keyConcepts: ["Simultaneous equations & advanced percentage ratios", "Chemistry elements, acids & bases foundation", "ICSE Shakespeare simplified literature drafts", "Historical timelines of Maharashtra"],
    weeklyPracticeLimit: "6 premium test sheets",
    milestones: ["Structure complex ICSE answers properly", "Understand atomic structures", "Perform high-speed mental algebra calculations"]
  },
  "middle-SSC": {
    speedTarget: "Writing speed target: 18-20 Words Per Minute (Structured layout)",
    keyConcepts: ["BODMAS integers & unitary math rules", "Marathi grammar sandhi & samas", "Science electricity basics, digestive systems", "Indian geography stats"],
    weeklyPracticeLimit: "4 board-pattern logs",
    milestones: ["Read & translate languages perfectly", "Draw pristine science layout diagrams", "Solve standard Maharashtra board SSC pattern mock sheets"]
  }
};

// Learning style Quiz
interface QuizQuestion {
  question: string;
  options: { text: string; category: string }[];
}

const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    question: "When explaining a exciting new board game, your child prefers to:",
    options: [
      { text: "Watch you play or read the board colors first", category: "Visual" },
      { text: "Listen to the rules spoken aloud verbally", category: "Auditory" },
      { text: "Jump right in and handle the cards/dice to figure it out", category: "Kinesthetic" },
      { text: "Read the back of the box instructions in detail", category: "ReadWrite" }
    ]
  },
  {
    question: "In school examinations, writing errors mostly arise because they:",
    options: [
      { text: "Forget what the textbook diagram or highlighted formulas looked like", category: "Visual" },
      { text: "Missed or misheard the verbal verbal guidance in school class", category: "Auditory" },
      { text: "Ran out of patience, rushing with messy cursive alignment", category: "Kinesthetic" },
      { text: "Felt rusty with word spells or textbook typing formats", category: "ReadWrite" }
    ]
  },
  {
    question: "During free weekends, which activity keeps them engaged longest?",
    options: [
      { text: "Watching animated clips, sketching patterns, or cartoon comics", category: "Visual" },
      { text: "Listening to sound tales, music, or narrating creative stories", category: "Auditory" },
      { text: "Building LEGO patterns, playing tag outdoors, or crafting clays", category: "Kinesthetic" },
      { text: "Filling puzzle logs, spell worksheets, or writing in personal notebooks", category: "ReadWrite" }
    ]
  },
  {
    question: "When reviewing tricky spellings, they find absolute ease by:",
    options: [
      { text: "Highlighting key letters in neon colors or flashcards", category: "Visual" },
      { text: "Spelling it out loud or recording their voice to listen", category: "Auditory" },
      { text: "Tracing words through sand plates, desk scratch, or body gestures", category: "Kinesthetic" },
      { text: "Writing the word 5 times cleanly in a raw study journal", category: "ReadWrite" }
    ]
  }
];

export default function InteractionHub() {
  const [activeTab, setActiveTab] = useState<'phonics' | 'handwriting' | 'syllabus' | 'quiz'>('phonics');

  // Phonics States
  const [selectedPhonic, setSelectedPhonic] = useState<PhonicBlend>(PHONICS_DATA[0]);
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);

  const speakText = (text: string, word?: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const textToSpeak = word ? word : text;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = 'en-IN'; // Elegant Indian English accent
      utterance.rate = 0.75; // Slower, clear pedagogy pace
      
      utterance.onstart = () => {
        setIsSpeaking(word || text);
      };
      
      utterance.onend = () => {
        setIsSpeaking(null);
      };

      utterance.onerror = () => {
        setIsSpeaking(null);
      };

      window.speechSynthesis.speak(utterance);
    } else {
      alert("Speech synthesis is not supported on this browser. Try opening the page in a fresh Chrome or Safari tab!");
    }
  };

  // Handwriting Analyzer States
  const [fileName, setFileName] = useState<string | null>(null);
  const [studentAge, setStudentAge] = useState<string>("8");
  const [studentName, setStudentName] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisProgress, setAnalysisProgress] = useState<number>(0);
  const [analysisResult, setAnalysisResult] = useState<{
    score: number;
    slant: string;
    letters: string;
    pacing: string;
    advice: string[];
    remedialSentences: string[];
  } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileName(e.target.files[0].name);
    }
  };

  const runAnalysis = () => {
    if (!studentName) {
      alert("Please enter the student name first to customize homework drills!");
      return;
    }
    setIsAnalyzing(true);
    setAnalysisProgress(10);
    setAnalysisResult(null);

    const interval = setInterval(() => {
      setAnalysisProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsAnalyzing(false);
            // Dynamic premium diagnostic results customized by age and standard
            const ageNum = parseInt(studentAge);
            const score = Math.floor(70 + Math.random() * 20); // 70 to 90
            let slant = "Slightly backward tilting (12° drag). Causes wrist strain.";
            let letters = "Irregular loops in cursive tails ('g', 'y', 'z'). Bottom loops colliding.";
            let pacing = ageNum <= 6 ? "Pencil grip is overly tight. Leads to early writing fatigue after 3 lines." : "Letter spacing is inconsistent. Tends to crowd words at margins.";
            
            let advice = [
              "Transition to high-grip hexagonal pencils to balance muscle tension.",
              "Conduct 2 pages of horizontal slider lines and nested wave looping daily.",
              "Introduce a spacer tool (a standard ice cream stick) to build uniform gap gaps.",
              "Avoid giving standard ball pens; promote high-friction 2B lead graphite."
            ];

            let remedialSentences = [
              "We love studying together in Bhusari Colony center classrooms.",
              "Quiet cozy study batches are fully ready for the standard tests.",
              "The quick brown fox jumps over the lazy dog cleanly."
            ];

            if (ageNum > 10) {
              slant = "Overly flat slant (25° forward drift). Affects readability at high speed.";
              letters = "Unclosed loops in 'a', 'o', 'd' causing evaluation confusion for school examiners.";
              pacing = "Pacing drops significantly under time-bound exam conditions.";
              advice = [
                "Practice board-pattern line booklets.",
                "Mandatory 20-minute daily speed challenge to lock clean alignment.",
                "Use broad-grip medium felt tips to avoid hand sweat cramps."
              ];
            }

            setAnalysisResult({ score, slant, letters, pacing, advice, remedialSentences });
          }, 600);
          return 100;
        }
        return prev + Math.floor(15 + Math.random() * 20);
      });
    }, 400);
  };

  // Syllabus Roadmap States
  const [syllabusStandard, setSyllabusStandard] = useState<'nursery' | 'primary' | 'middle'>('primary');
  const [syllabusBoard, setSyllabusBoard] = useState<'CBSE' | 'ICSE' | 'SSC'>('CBSE');

  const roadmapKey = `${syllabusStandard}-${syllabusBoard}`;
  const currentRoadmap = SYLLABUS_ROADMAPS[roadmapKey] || SYLLABUS_ROADMAPS["primary-CBSE"];

  // Quiz States
  const [quizIndex, setQuizIndex] = useState<number>(-1); // -1 = start, 0-3 = questions, 4 = result
  const [quizResponses, setQuizResponses] = useState<string[]>([]);
  const [finalStyle, setFinalStyle] = useState<string | null>(null);

  const startQuiz = () => {
    setQuizIndex(0);
    setQuizResponses([]);
    setFinalStyle(null);
  };

  const handleQuizAnswer = (category: string) => {
    const updated = [...quizResponses, category];
    setQuizResponses(updated);
    
    if (quizIndex < QUIZ_QUESTIONS.length - 1) {
      setQuizIndex(prev => prev + 1);
    } else {
      // Calculate majority category
      const counts: Record<string, number> = {};
      let maxCat = "Visual";
      let maxCount = 0;
      
      updated.forEach(cat => {
        counts[cat] = (counts[cat] || 0) + 1;
        if (counts[cat] > maxCount) {
          maxCount = counts[cat];
          maxCat = cat;
        }
      });
      
      setFinalStyle(maxCat);
      setQuizIndex(4); // Result view
    }
  };

  const getStyleDescription = (style: string) => {
    switch(style) {
      case 'Visual': 
        return {
          title: "🎨 Dominant Visual Learner",
          desc: "Your child absorbs lessons best through diagrams, colorful schematics, reading cursive stories, maps, and high-contrast flashcards rather than verbal lecture explanations.",
          friction: "Dulls or loses interest quickly during plain spoken monologues or un-illustrated school booklets.",
          tuitionPlan: "Our home tutors map courses onto visual mind-maps, whiteboard illustration activities, and concept charts."
        };
      case 'Auditory':
        return {
          title: "🎙️ Dominant Auditory Learner",
          desc: "Your child thrives on rhyming patterns, stories told verbally, active listening, dialogue questioning, and sounding out phonics rules loud.",
          friction: "Easily distracted by subtle background house noise; struggles to retain quiet text-only worksheets.",
          tuitionPlan: "Specialized verbal testing, soundboard phonemic coaching, and interactive dialogue-based home evaluations."
        };
      case 'Kinesthetic':
        return {
          title: "🏃 Dominant Kinesthetic / Tactile Learner",
          desc: "Your child learns by handling physical elements, blocks, building diagrams, counting objects, and writing active stroke movements.",
          friction: "Labelled as 'energetic' or 'restless' in massive traditional classrooms. Needs to move muscles to process logic.",
          tuitionPlan: "Integrating hands-on counting rods, kinetic board tracing, scheduled mini break gaps, and high-frequency tactile writing."
        };
      default: // ReadWrite
        return {
          title: "✍️ Dominant Read/Write Learner",
          desc: "Your child excels at reading text, copying cursive exercises, making structured lists, and reading textbooks repeatedly.",
          friction: "May struggle with rapid practical visual-motor activities unless structured first into clear written checklists.",
          tuitionPlan: "Formulating custom printable worksheets, spelling notebooks, detailed progress charts, and clear exam prep mock files."
        };
    }
  };

  return (
    <section id="discovery-hub" className="py-20 bg-[#FAF8F2] relative overflow-hidden font-sans border-t border-brand-primary/10">
      
      {/* Dynamic Background Accents mapping to Forest Luxe style */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-brand-secondary/5 rounded-full blur-3xl -translate-y-20 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-brand-accent/5 rounded-full blur-3xl translate-y-20 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <span className="text-brand-secondary text-xs font-black tracking-widest uppercase font-mono bg-[#EBF5F2] px-3.5 py-1.5 rounded-full border border-brand-secondary/20">
            ADVANCED PARENT HUD
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif text-brand-primary tracking-tight font-black">
            AI Parent Diagnostic & Interactive Learning Hub
          </h2>
          <p className="text-sm sm:text-base text-brand-dark/80 font-medium">
            Tired of boring static layouts? Explore our diagnostic widgets. Play with our phoneme sounds, evaluate child handwriting slant, track class syllabus benchmarks, or unlock learning-style analyses.
          </p>
        </div>

        {/* Tab Selection Area - Forest Slate styled */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 p-1.5 bg-[#092E21]/5 rounded-2xl max-w-4xl mx-auto border border-[#092E21]/10">
          <button
            onClick={() => setActiveTab('phonics')}
            className={`flex items-center justify-center gap-2 py-3.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'phonics'
                ? 'bg-brand-primary text-[#FCFAF4] shadow-md'
                : 'text-[#092E21] hover:bg-[#092E21]/5'
            }`}
          >
            <Volume2 className="w-4 h-4 shrink-0" />
            <span>Phonics Board</span>
          </button>

          <button
            onClick={() => setActiveTab('handwriting')}
            className={`flex items-center justify-center gap-2 py-3.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'handwriting'
                ? 'bg-brand-primary text-[#FCFAF4] shadow-md'
                : 'text-[#092E21] hover:bg-[#092E21]/5'
            }`}
          >
            <PenTool className="w-4 h-4 shrink-0" />
            <span>Stroke Analyzer</span>
          </button>

          <button
            onClick={() => setActiveTab('syllabus')}
            className={`flex items-center justify-center gap-2 py-3.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'syllabus'
                ? 'bg-brand-primary text-[#FCFAF4] shadow-md'
                : 'text-[#092E21] hover:bg-[#092E21]/5'
            }`}
          >
            <Compass className="w-4 h-4 shrink-0" />
            <span>Syllabus Roadmap</span>
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`flex items-center justify-center gap-2 py-3.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'quiz'
                ? 'bg-brand-primary text-[#FCFAF4] shadow-md'
                : 'text-[#092E21] hover:bg-[#092E21]/5'
            }`}
          >
            <BrainCircuit className="w-4 h-4 shrink-0" />
            <span>Learning Style</span>
          </button>
        </div>

        {/* Core Frame Output Container */}
        <div className="mt-8 max-w-5xl mx-auto bg-[#FCFAF4] rounded-3xl border-2 border-[#092E21]/14 shadow-xl overflow-hidden min-h-[480px] flex flex-col justify-between">
          <div className="p-6 sm:p-8 flex-1">
            <AnimatePresence mode="wait">
              
              {/* Tab 1: Phonics board */}
              {activeTab === 'phonics' && (
                <motion.div
                  key="phonics-pane"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="grid grid-cols-1 md:grid-cols-12 gap-8"
                >
                  <div className="md:col-span-7 space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="bg-emerald-100 text-brand-secondary text-[10px] font-black px-2.5 py-1 rounded-full font-mono uppercase border border-brand-secondary/15">Montessori Practice</span>
                        <span className="text-xs text-brand-dark/60 font-semibold">Real Sound Synthesizer</span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-serif text-brand-primary font-black">Spelling Blend Interactive Board</h3>
                      <p className="text-xs sm:text-sm text-brand-dark/75 leading-relaxed">
                        Improve spelling speed & articulation. Select a key vocal blend below, then click vocabulary badges to hear custom teacher articulation guides in real-time!
                      </p>
                    </div>

                    {/* Blend selections */}
                    <div className="grid grid-cols-4 gap-2">
                      {PHONICS_DATA.map((item) => (
                        <button
                          key={item.blend}
                          onClick={() => setSelectedPhonic(item)}
                          className={`p-3 rounded-xl border text-center transition-all cursor-pointer relative ${
                            selectedPhonic.blend === item.blend
                              ? 'bg-brand-secondary border-brand-secondary text-white font-black shadow-md'
                              : 'bg-white border-[#092E21]/10 text-brand-primary font-semibold hover:bg-slate-50'
                          }`}
                        >
                          <span className="text-base font-mono block">/{item.blend}/</span>
                          <span className="text-[9px] opacity-75 font-medium">{item.recommendedAge}</span>
                        </button>
                      ))}
                    </div>

                    {/* Instruction Alert */}
                    <div className="bg-[#EBF5F2] border border-brand-secondary/15 p-4 rounded-xl flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shrink-0 border border-brand-secondary/10">
                        <Sparkles className="w-4 h-4 text-brand-secondary" />
                      </div>
                      <div>
                        <p className="text-xs font-black text-brand-primary">Mouth Positioning Cue:</p>
                        <p className="text-[11px] text-brand-dark/80 mt-0.5 leading-relaxed font-semibold">{selectedPhonic.tongueCue}</p>
                      </div>
                    </div>
                  </div>

                  {/* Sidebar wordboard */}
                  <div className="md:col-span-5 bg-white p-6 rounded-2xl border border-[#092E21]/10 shadow-sm flex flex-col justify-between">
                    <div className="space-y-4">
                      <div className="pb-3 border-b border-[#092E21]/10 flex justify-between items-center">
                        <span className="text-xs font-black text-brand-primary font-mono select-none">SOUND DRILLS: /{selectedPhonic.blend}/</span>
                        <span className="text-[10px] bg-brand-accent/15 text-brand-primary px-2 py-0.5 rounded-full font-black uppercase font-mono">{selectedPhonic.recommendedAge}</span>
                      </div>

                      {/* Speaking indicator / word grids */}
                      <div className="space-y-2.5">
                        {selectedPhonic.exampleWords.map((word) => {
                          const currentlySpeaking = isSpeaking === word;
                          return (
                            <button
                              key={word}
                              onClick={() => speakText(`The phonics word is ${word}. Pronounced with a clean back accent as /${selectedPhonic.blend}/ in ${word}`, word)}
                              className={`w-full text-left p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer select-none ${
                                currentlySpeaking
                                  ? 'bg-brand-accent/20 border-brand-accent text-brand-primary ring-1 ring-brand-accent'
                                  : 'bg-slate-50 hover:bg-slate-100 border-slate-150 text-slate-800'
                              }`}
                            >
                              <span className="text-sm font-black tracking-wide font-serif">{word}</span>
                              <div className="flex items-center gap-1.5">
                                <span className="text-[9px] font-mono text-slate-400 font-bold uppercase">{currentlySpeaking ? 'SPEAKING...' : 'PLAY SOUND'}</span>
                                <Volume2 className={`w-4 h-4 ${currentlySpeaking ? 'text-brand-accent animate-bounce' : 'text-slate-400'}`} />
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <button
                      onClick={() => speakText(selectedPhonic.audioCue)}
                      className="w-full mt-6 bg-[#092E21] hover:bg-emerald-950 text-[#FCFAF4] py-3.5 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 select-none active:scale-95 transition-transform"
                    >
                      <Volume2 className="w-4 h-4" />
                      Play Teacher Vocal Cue
                    </button>
                  </div>
                </motion.div>
              )}

              {/* Tab 2: Handwriting Analyzer */}
              {activeTab === 'handwriting' && (
                <motion.div
                  key="handwriting-pane"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <span className="bg-amber-100 text-[#854D0E] text-[10px] font-black px-2.5 py-1 rounded-full font-mono uppercase border border-amber-200">Qualitative Scanner</span>
                    <h3 className="text-xl sm:text-2xl font-serif text-brand-primary font-black">Cursive Alignment & Spacing Analyzer</h3>
                    <p className="text-xs sm:text-sm text-brand-dark/75 leading-relaxed">
                      Messy margins or hand fatigue? Fill in your child's age profile, type in a target practice sentence or mock-upload a scan of their handwriting to unlock our targeted remedial copybook drills.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                    {/* Controls on Left */}
                    <div className="md:col-span-5 space-y-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
                      
                      {/* Name input */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-brand-primary uppercase tracking-wide font-mono block">Student Name</label>
                        <input
                          type="text"
                          placeholder="e.g. Advait Kulkarni"
                          value={studentName}
                          onChange={(e) => setStudentName(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 text-xs sm:text-sm p-3 rounded-xl focus:outline-none focus:ring-1 focus:ring-brand-secondary font-semibold text-slate-800"
                        />
                      </div>

                      {/* Age range */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center">
                          <label className="text-[10px] font-black text-brand-primary uppercase tracking-wide font-mono block">Student Age</label>
                          <span className="text-xs font-black text-brand-secondary font-mono">{studentAge} Years Old</span>
                        </div>
                        <input
                          type="range"
                          min="4"
                          max="15"
                          value={studentAge}
                          onChange={(e) => setStudentAge(e.target.value)}
                          className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-secondary"
                        />
                      </div>

                      {/* File select drop area */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-brand-primary uppercase tracking-wide font-mono block">Upload Photo of Hand Written Homework (Optional)</label>
                        <div className="border border-dashed border-slate-300 rounded-xl p-4 bg-slate-50/50 text-center hover:bg-slate-50 transition-colors relative cursor-pointer group">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleFileChange}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                          />
                          <Upload className="w-5 h-5 mx-auto text-slate-400 group-hover:scale-110 transition-transform" />
                          <p className="text-[10px] font-bold text-slate-600 mt-2">
                            {fileName ? `✓ Selected: ${fileName}` : "Click to select or drag homework picture"}
                          </p>
                          <p className="text-[8px] text-slate-400 mt-0.5">Supports JPG, PNG (Max 5MB)</p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={runAnalysis}
                        disabled={isAnalyzing}
                        className="w-full bg-[#092E21] hover:bg-emerald-950 text-[#FCFAF4] py-3.5 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer"
                      >
                        {isAnalyzing ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Analyzing Stroke Frame... ({analysisProgress}%)</span>
                          </>
                        ) : (
                          <>
                            <PenTool className="w-4 h-4 animate-pulse" />
                            <span>Evaluate Homework Slant</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Results on Right */}
                    <div className="md:col-span-7">
                      {isAnalyzing ? (
                        <div className="bg-white rounded-2xl border border-slate-200/80 p-12 text-center flex flex-col items-center justify-center h-[340px] space-y-4 shadow-sm">
                          <div className="w-14 h-14 rounded-full bg-[#EBF5F2] text-brand-secondary flex items-center justify-center animate-spin border-t-2 border-brand-secondary">
                            <PenTool className="w-6 h-6 animate-pulse" />
                          </div>
                          <div>
                            <p className="text-sm font-black text-brand-primary">Initiating Cursive baseline alignment scan...</p>
                            <p className="text-xs text-slate-500 mt-1">Measuring vertical loop parameters & slant uniformity in Bhusari Colony database...</p>
                          </div>
                          {/* Progress bar */}
                          <div className="w-full max-w-xs bg-slate-100 rounded-full h-2">
                            <div className="bg-brand-secondary h-2 rounded-full transition-all duration-300" style={{ width: `${analysisProgress}%` }}></div>
                          </div>
                        </div>
                      ) : analysisResult ? (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="bg-white rounded-2xl border-2 border-[#0A856D]/20 p-6 space-y-5 shadow-md"
                        >
                          {/* Result Header */}
                          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                            <div>
                              <p className="text-[10px] font-black text-brand-secondary uppercase font-mono tracking-wider">Interactive Report Card</p>
                              <h4 className="text-base font-black text-brand-primary font-serif">Diagnosis for {studentName}</h4>
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] block font-mono font-bold text-slate-400">QUALITY SCORE</span>
                              <span className={`text-2xl font-mono font-black ${analysisResult.score >= 80 ? 'text-emerald-600' : 'text-brand-accent'}`}>
                                {analysisResult.score}/100
                              </span>
                            </div>
                          </div>

                          {/* Metric stats */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-slate-400 font-mono text-[9px] block">SLANT ANALYSIS</span>
                              <span className="font-bold text-slate-800 line-clamp-2">{analysisResult.slant}</span>
                            </div>
                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-slate-400 font-mono text-[9px] block">LETTER SYMMETRY</span>
                              <span className="font-bold text-slate-800 line-clamp-2">{analysisResult.letters}</span>
                            </div>
                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-slate-400 font-mono text-[9px] block">FATIGUE & PACING</span>
                              <span className="font-bold text-slate-800 line-clamp-2">{analysisResult.pacing}</span>
                            </div>
                          </div>

                          {/* Custom advice lists */}
                          <div className="space-y-2">
                            <p className="text-[10px] font-black text-brand-primary uppercase font-mono tracking-wider">Academic Clinical Remedials:</p>
                            <ul className="space-y-1.5 text-xs text-slate-700 font-semibold">
                              {analysisResult.advice.map((adv, i) => (
                                <li key={i} className="flex items-start gap-1.5">
                                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                                  <span>{adv}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Print sentence block */}
                          <div className="bg-[#FAF8F2] border border-[#092E21]/10 p-3.5 rounded-xl">
                            <p className="text-[10px] font-black text-brand-primary uppercase font-mono">Suggested Slant Practice Sentences:</p>
                            <div className="mt-2 space-y-1 font-mono text-[11px] text-slate-650 font-semibold border-l-2 border-brand-accent pl-3 italic">
                              {analysisResult.remedialSentences.map((s, idx) => (
                                <p key={idx}>"{s}"</p>
                              ))}
                            </div>
                          </div>

                        </motion.div>
                      ) : (
                        <div className="bg-white rounded-2xl border border-dashed border-slate-350 p-8 text-center flex flex-col items-center justify-center h-[340px] text-slate-400 space-y-3 shadow-xs">
                          <PenTool className="w-8 h-8 text-slate-300" />
                          <div>
                            <p className="text-sm font-black text-brand-primary">Waiting for Homework Evaluation Details</p>
                            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                              Enter your child's name, age and click 'Evaluate Homework Slant' to generate standard-aligned remediation. No card/payment required!
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Tab 3: Syllabus Roadmap */}
              {activeTab === 'syllabus' && (
                <motion.div
                  key="syllabus-pane"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <span className="bg-[#EBF5F2] text-brand-secondary text-[10px] font-black px-2.5 py-1 rounded-full font-mono uppercase border border-brand-secondary/15">Syllabus Sync</span>
                    <h3 className="text-xl sm:text-2xl font-serif text-brand-primary font-black">SSC / CBSE / ICSE Standardized Curriculum Maps</h3>
                    <p className="text-xs sm:text-sm text-brand-dark/75 leading-relaxed">
                      Select your child’s standard wing and target educational board. Instantly access the customized milestone pacing schedule, writing-speed requirements, and weekly practice criteria mapped to Pune curricula.
                    </p>
                  </div>

                  {/* Selection controls */}
                  <div className="flex flex-col sm:flex-row gap-4 bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs">
                    
                    {/* Standard selector */}
                    <div className="flex-1 space-y-1.5">
                      <label className="text-[10px] font-black text-brand-primary uppercase tracking-wide font-mono block">Grade Category</label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['nursery', 'primary', 'middle'] as const).map((std) => (
                          <button
                            key={std}
                            onClick={() => setSyllabusStandard(std)}
                            className={`py-2 px-3 rounded-lg border text-xs text-center font-bold tracking-wide transition-all cursor-pointer ${
                              syllabusStandard === std
                                ? 'bg-brand-primary text-white border-brand-primary shadow'
                                : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                            }`}
                          >
                            {std === 'nursery' ? '👶 Nursery (Pre)' : std === 'primary' ? '🏫 Primary (1-4)' : '🎓 Middle (5-8)'}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Board Selector */}
                    <div className="flex-1 space-y-1.5">
                      <label className="text-[10px] font-black text-brand-primary uppercase tracking-wide font-mono block"> Pune Board Affiliation</label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['CBSE', 'ICSE', 'SSC'] as const).map((brd) => (
                          <button
                            key={brd}
                            onClick={() => setSyllabusBoard(brd)}
                            className={`py-2 px-3 rounded-lg border text-xs text-center font-bold tracking-wide transition-all cursor-pointer ${
                              syllabusBoard === brd
                                ? 'bg-brand-secondary text-white border-brand-secondary shadow'
                                : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                            }`}
                          >
                            {brd} Board
                          </button>
                        ))}
                      </div>
                    </div>

                  </div>

                  {/* Detailed Roadmap results */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
                    
                    {/* Roadmap core blocks */}
                    <div className="md:col-span-8 bg-white p-6 rounded-2xl border border-[#092E21]/10 shadow-xs space-y-4">
                      
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                        <span className="text-xs font-black text-brand-primary font-mono select-none uppercase">Target: {syllabusStandard} School ({syllabusBoard} Board)</span>
                        <span className="bg-amber-100 text-[#854D0E] text-[9px] font-mono px-2 py-0.5 rounded-full font-black uppercase">Approved Pacing</span>
                      </div>

                      {/* Speed Targets */}
                      <div className="bg-[#FAF8F2] border border-[#092E21]/10 p-3.5 rounded-xl flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center font-mono font-black text-brand-accent shrink-0 border border-brand-accent/20">
                          WPM
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase font-mono">Writing Competency Goal:</p>
                          <p className="text-xs font-black text-brand-primary mt-0.5">{currentRoadmap.speedTarget}</p>
                        </div>
                      </div>

                      {/* Core Concepts */}
                      <div className="space-y-2">
                        <p className="text-[10px] font-black text-[#0D947B] uppercase font-mono tracking-wider">Milestone Academic Concepts Covered:</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {currentRoadmap.keyConcepts.map((concept, idx) => (
                            <div key={idx} className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center gap-2 text-xs">
                              <span className="w-1.5 h-1.5 rounded-full bg-brand-secondary shrink-0"></span>
                              <span className="text-slate-800 font-semibold leading-relaxed truncate" title={concept}>{concept}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>

                    {/* Milestone Check checklists */}
                    <div className="md:col-span-4 bg-slate-900 text-white p-5 rounded-2xl flex flex-col justify-between border border-slate-800 shadow-lg">
                      <div className="space-y-4">
                        <div className="pb-3 border-b border-white/10">
                          <p className="text-[10px] font-black text-emerald-400 uppercase font-mono tracking-widest">Active Checklist</p>
                          <h4 className="text-sm font-black font-serif text-white mt-1">Standard Milestones</h4>
                        </div>
                        <ul className="space-y-3 text-[11px] text-slate-300 font-semibold leading-relaxed">
                          {currentRoadmap.milestones.map((m, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5 stroke-[3]" />
                              <span>{m}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="pt-6 border-t border-white/10 mt-6 space-y-1 text-center">
                        <p className="text-[10px] text-slate-400 font-bold uppercase font-mono">Center Practice allocation:</p>
                        <p className="text-xs font-black text-amber-400">{currentRoadmap.weeklyPracticeLimit}</p>
                      </div>
                    </div>

                  </div>
                </motion.div>
              )}

              {/* Tab 4: Learning style quiz */}
              {activeTab === 'quiz' && (
                <motion.div
                  key="quiz-pane"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-6"
                >
                  {quizIndex === -1 && (
                    /* Quiz Intro screen */
                    <div className="text-center py-12 max-w-xl mx-auto space-y-6 flex flex-col items-center justify-center min-h-[300px]">
                      <div className="w-14 h-14 rounded-full bg-[#EBF5F2] text-brand-secondary flex items-center justify-center border border-brand-secondary/20">
                        <BrainCircuit className="w-7 h-7" />
                      </div>
                      <div className="space-y-2">
                        <h3 className="text-2xl font-serif text-brand-primary font-black">Discover Your Child’s Learning Style</h3>
                        <p className="text-xs sm:text-sm text-brand-dark/75 leading-relaxed font-medium">
                          Every student has a distinct mental wiring. Is your child Visual, Auditory, Kinesthetic, or Read/Write-oriented? Answer 4 quick behavioral questions to unlocked tailored homework habits.
                        </p>
                      </div>
                      <button
                        onClick={startQuiz}
                        className="bg-brand-secondary hover:bg-[#0A856D]/90 text-white font-black py-4 px-8 rounded-xl text-xs uppercase tracking-widest flex items-center gap-2 select-none active:scale-95 transition-transform cursor-pointer shadow"
                      >
                        Start Diagnostic Questionnaire
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {quizIndex >= 0 && quizIndex <= 3 && (
                    /* Active Question Screen */
                    <div className="space-y-6 max-w-2xl mx-auto">
                      <div className="flex justify-between items-center pb-3 border-b border-slate-100 font-mono text-[10px] font-black text-slate-400">
                        <span>LEARNING ARCHETYPE DIAGNOSIS</span>
                        <span>QUESTION {quizIndex + 1} OF 4</span>
                      </div>

                      {/* Bar indicator */}
                      <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
                        <div className="bg-brand-secondary h-1" style={{ width: `${(quizIndex + 1) * 25}%` }}></div>
                      </div>

                      <h4 className="text-lg sm:text-xl font-bold font-serif text-brand-primary leading-snug">
                        {QUIZ_QUESTIONS[quizIndex].question}
                      </h4>

                      <div className="grid grid-cols-1 gap-3 pt-2">
                        {QUIZ_QUESTIONS[quizIndex].options.map((opt, i) => (
                          <button
                            key={i}
                            onClick={() => handleQuizAnswer(opt.category)}
                            className="w-full text-left p-4 rounded-xl border border-slate-250 hover:border-brand-secondary hover:bg-[#EBF5F2]/30 text-xs sm:text-sm font-semibold text-slate-800 transition-all cursor-pointer relative flex items-center gap-3 active:scale-99"
                          >
                            <span className="w-6 h-6 rounded-full bg-slate-100 team-hover:bg-brand-secondary/20 flex items-center justify-center font-mono text-slate-400 text-[10px] font-black group-hover:text-brand-secondary">
                              {['A', 'B', 'C', 'D'][i]}
                            </span>
                            <span>{opt.text}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {quizIndex === 4 && finalStyle && (
                    /* Quiz Results Output Screen */
                    <motion.div
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch"
                    >
                      {/* Left: dominant badge matrix */}
                      <div className="md:col-span-8 bg-white p-6 rounded-2xl border border-brand-secondary/20 shadow-sm space-y-5 flex flex-col justify-between">
                        <div className="space-y-3">
                          <span className="bg-emerald-100 text-brand-secondary text-[9px] font-black px-2.5 py-1 rounded-full font-mono uppercase tracking-wider">Diagnostic Results</span>
                          <h4 className="text-2xl font-serif text-brand-primary font-black">
                            {getStyleDescription(finalStyle).title}
                          </h4>
                          <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-semibold">
                            {getStyleDescription(finalStyle).desc}
                          </p>
                        </div>

                        {/* Friction block */}
                        <div className="bg-red-50/70 border border-red-100 p-4 rounded-xl">
                          <p className="text-[10px] font-black text-red-900 uppercase font-mono block">Potential Classroom Conflict / Friction:</p>
                          <p className="text-xs text-red-950 mt-0.5 leading-relaxed font-semibold">{getStyleDescription(finalStyle).friction}</p>
                        </div>

                        {/* Action details */}
                        <div className="bg-[#FAF8F2] border border-[#092E21]/10 p-4 rounded-xl">
                          <p className="text-[10px] font-black text-brand-primary uppercase font-mono block">Recommended Homework Tactics:</p>
                          <p className="text-xs text-brand-dark/85 mt-0.5 leading-relaxed font-semibold">{getStyleDescription(finalStyle).tuitionPlan}</p>
                        </div>
                      </div>

                      {/* Right: prompt slot match */}
                      <div className="md:col-span-4 bg-[#092E21] text-white p-5 rounded-2xl flex flex-col justify-between border border-emerald-950 shadow-lg text-center items-center">
                        <div className="space-y-4 py-4">
                          <div className="w-12 h-12 rounded-full bg-white/10 text-brand-accent flex items-center justify-center animate-bounce">
                            <Award className="w-6 h-6 text-brand-accent" />
                          </div>
                          <div>
                            <h5 className="text-sm font-black font-serif text-white">Unlock Full Diagnostic</h5>
                            <p className="text-xs text-slate-300 mt-2 leading-relaxed font-medium">
                              Secure a free home trial with a senior Kothrud tutor skilled in accommodating <strong className="text-brand-accent font-black">{finalStyle} Learners</strong>.
                            </p>
                          </div>
                        </div>

                        <div className="w-full space-y-2">
                          <button
                            onClick={() => {
                              const text = `Hello Kothrud Home Tuition Academy! I ran the learning-style quiz and matched a dominant "${finalStyle}" child profile. I would like a consultation callback and free evaluation class!`;
                              window.open(`https://wa.me/919172415302?text=${encodeURIComponent(text)}`, '_blank');
                            }}
                            className="w-full bg-brand-accent hover:bg-yellow-600 text-white font-black py-3.5 rounded-xl text-[10px] uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all select-none"
                          >
                            <Phone className="w-3.5 h-3.5 fill-current" />
                            Book Style Match Trial
                          </button>
                          <button
                            onClick={startQuiz}
                            className="text-[10px] text-slate-300 font-bold hover:text-white transition-colors uppercase tracking-wider pt-2"
                          >
                            Retake Diagnostic Quiz
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

            </AnimatePresence>
          </div>

          {/* Secure disclaimer bar */}
          <div className="bg-[#092E21] border-t border-emerald-950 p-4 px-6 sm:px-8 text-white font-mono text-[9px] flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
            <span>💻 COGNITIVE METHODOLOGY COMPLIANT & APPROVED FOR CBSE/ICSE INQUIRIES</span>
            <span className="text-brand-accent hover:underline cursor-pointer select-none font-bold" onClick={() => speakText("Your child possesses dynamic capability. Our home tuition is built around active, supportive pacing rather than stressful school speed. Book a demo today!")}>
              🔊 CLICK HERE FOR VOICE OUTLINE GUIDE
            </span>
          </div>
        </div>

      </div>
    </section>
  );
}
