import React, { useState, useEffect } from 'react';
import { 
  motion, 
  AnimatePresence 
} from 'motion/react';
import { 
  Phone, 
  Award, 
  Users, 
  UserCheck, 
  IndianRupee, 
  TrendingUp, 
  CalendarCheck, 
  Sparkles, 
  MapPin, 
  Star, 
  Menu, 
  X, 
  Send, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  BookOpen, 
  GraduationCap, 
  Laptop, 
  PenTool, 
  Compass, 
  Volume2, 
  BrainCircuit, 
  HelpCircle,
  Clock,
  ArrowRight
} from 'lucide-react';
import { 
  SELLING_POINTS, 
  ACADEMIC_COURSES, 
  SKILL_PROGRAMS, 
  METHODOLOGY_STEPS, 
  TESTIMONIALS, 
  FAQS 
} from './data';
import InteractionHub from './components/InteractionHub';

export default function App() {
  // Navigation State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Tab State for Courses
  const [courseTab, setCourseTab] = useState<'academic' | 'skill'>('academic');

  // FAQ Accordion State
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Form State
  const [formData, setFormData] = useState({
    studentName: '',
    standard: '1st Standard',
    subject: 'Mathematics',
    parentName: '',
    phoneNumber: '',
    locationPreference: 'Home Tuition', // Home Tuition or Bhusari Colony Batch
  });
  
  // Real-time Booking Toast Simulation for high social proof
  const [bookingToast, setBookingToast] = useState<{message: string; visible: boolean}>({message: '', visible: false});
  const toastBank = [
    "Mrs. Shital K. from Bavdhan just booked a Math Demo Class! 🎉",
    "Parent of Advait (4th Std) from Bhusari Colony requested Phonics material ✉️",
    "Mr. Prasad Joshi from Karve Nagar enrolled for premium Home Tuition 🌟",
    "Mrs. Tambe from Warje booked private One-to-One Demo session! 🏠",
    "Class 1-4 standard batch from Kothrud is now 90% full! ⚡"
  ];

  // Exit intent popup state
  const [showExitPopup, setShowExitPopup] = useState(false);
  const [hasShownExitPopup, setHasShownExitPopup] = useState(false);

  // Active form submission state
  const [formSubmitted, setFormSubmitted] = useState(false);

  // Matchmaker & Fee Estimator State
  const [matchGrade, setMatchGrade] = useState<'early' | 'primary' | 'middle' | 'skills'>('primary');
  const [matchMode, setMatchMode] = useState<'home' | 'academy'>('home');
  const [matchFrequency, setMatchFrequency] = useState<number>(3); // 2, 3, or 5 days per week

  const calculateFees = () => {
    let hourlyBase = 300;
    if (matchGrade === 'early') {
      hourlyBase = matchMode === 'home' ? 280 : 180;
    } else if (matchGrade === 'primary') {
      hourlyBase = matchMode === 'home' ? 320 : 220;
    } else if (matchGrade === 'middle') {
      hourlyBase = matchMode === 'home' ? 420 : 280;
    } else { // skills
      hourlyBase = matchMode === 'home' ? 350 : 240;
    }

    // adjustments based on frequency (bulk discount for 5 times/week)
    let discount = 1.0;
    if (matchFrequency === 5) {
      discount = 0.90; // 10% discount
    } else if (matchFrequency === 2) {
      discount = 1.05; // 5% weekend specialty
    }

    const hourlyRate = Math.round(hourlyBase * discount);
    const classesPerMonth = matchFrequency * 4;
    const hoursPerClass = 1.5;
    const monthlyTotal = Math.round(hourlyRate * hoursPerClass * classesPerMonth);

    // matching tutor profile info based on selected grade
    let recommendedTutor = {
      name: "Mrs. Anjali Deshmukh",
      badge: "Founder & Early Literacy Coach",
      experience: "22+ Years",
      specialty: "Phonics, Motor skill work, Nursery language basics",
      rating: "5.0/5 (180+ Reviews)",
      icon: "Award"
    };

    if (matchGrade === 'primary') {
      recommendedTutor = {
        name: "Mr. Sandeep Patil",
        badge: "Senior Math Foundation Tutor",
        experience: "15+ Years",
        specialty: "Interactive Math, EVS & Science (Standard 1st-4th)",
        rating: "4.8/5 (240+ Reviews)",
        icon: "UserCheck"
      };
    } else if (matchGrade === 'middle') {
      recommendedTutor = {
        name: "Mrs. Smita Kulkarni",
        badge: "Senior Academic Coordinator",
        experience: "20+ Years",
        specialty: "Class 5th-8th CBSE/ICSE High-Score Prep",
        rating: "4.9/5 (310+ Reviews)",
        icon: "TrendingUp"
      };
    } else if (matchGrade === 'skills') {
      recommendedTutor = {
        name: "Ms. Neha Shah",
        badge: "Creative Wings Specialist",
        experience: "8+ Years",
        specialty: "Cursive flow, Speed handwriting, Scratch Coding",
        rating: "4.9/5 (95+ Reviews)",
        icon: "Sparkles"
      };
    }

    return { hourlyRate, monthlyTotal, recommendedTutor };
  };

  const handleMatchmakerCTA = () => {
    const { monthlyTotal, recommendedTutor } = calculateFees();
    const gradeLabel = 
      matchGrade === 'early' ? 'Nursery / early KG foundation' : 
      matchGrade === 'primary' ? 'Primary Wing (1st-4th Std)' : 
      matchGrade === 'middle' ? 'Middle School (5th-8th Std)' : 
      'Specialist Skills';
    
    const modeLabel = matchMode === 'home' ? 'One-to-One Home Tuition' : 'Small Batch Center Lessons';

    const text = `Hello Kothrud Home Tuition Academy! I used your interactive Matchmaker & Estimator. I want to schedule a trial with *${recommendedTutor.name}* (${recommendedTutor.badge}) for standard: *${gradeLabel}*, Mode: *${modeLabel}*, Frequency: *${matchFrequency} days/week*. Calculated budget estimate: *₹${monthlyTotal}/month*. Please verify available trial slots!`;
    window.open(getWhatsAppURL(text), '_blank');
  };

  // WhatsApp configuration
  const WHATSAPP_NUMBER = "919172415302"; // Pune Academic Line

  // Triggering Booking Toast periodically
  useEffect(() => {
    const showToastRandomly = () => {
      const randomIndex = Math.floor(Math.random() * toastBank.length);
      setBookingToast({
        message: toastBank[randomIndex],
        visible: true
      });

      // Hide after 6 seconds
      setTimeout(() => {
        setBookingToast(prev => ({...prev, visible: false}));
      }, 6000);
    };

    // First toast after 4 seconds
    const initialTimeout = setTimeout(showToastRandomly, 4000);
    
    // Repeat every 25 seconds
    const interval = setInterval(showToastRandomly, 25000);

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    };
  }, []);

  // Exit Intent Event Listener (Desktop detection: mouse leaving top of screen)
  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY < 20 && !hasShownExitPopup) {
        setShowExitPopup(true);
        setHasShownExitPopup(true);
      }
    };

    // Mobile backup: Auto show after 20 seconds
    const mobileTimeout = setTimeout(() => {
      if (!hasShownExitPopup) {
        setShowExitPopup(true);
        setHasShownExitPopup(true);
      }
    }, 20000);

    document.addEventListener('mouseleave', handleMouseLeave);
    return () => {
      document.removeEventListener('mouseleave', handleMouseLeave);
      clearTimeout(mobileTimeout);
    };
  }, [hasShownExitPopup]);

  // Helper to generate dynamic WhatsApp URL based on actions
  const getWhatsAppURL = (messageText: string) => {
    const encodedText = encodeURIComponent(messageText);
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodedText}`;
  };

  // Pre-filled WhatsApp CTAs
  const handleDirectCTA = (ctaType: string, courseName?: string) => {
    let text = "";
    if (courseName) {
      text = `Hello Kothrud Home Tuition Academy! I am looking for details regarding the "${courseName}" course. Please guide me about batch timetables, fees, and home tutor availability near me in Pune.`;
    } else {
      switch(ctaType) {
        case 'demo':
          text = "Hello Kothrud Home Tuition Academy! I would like to book a FREE trial demo class for my child. Please share the slots and profiles of available home tutors in Kothrud Pune.";
          break;
        case 'consultation':
          text = "Hello! I want a free counseling session regarding my child's studies and handwriting progress. Please arrange a call back from your head tutor.";
          break;
        case 'batch':
          text = "Hello! I am inquiring about the small batch tuition timings and pricing at your Bhusari Colony academy center in Kothrud.";
          break;
        default:
          text = "Hello! I am visiting your website and would like to inquire about academic tuition and skill programs for my child in Kothrud Kothrud dep/Bhusari Colony.";
      }
    }
    window.open(getWhatsAppURL(text), '_blank');
  };

  // Custom Form Submit: redirects to WhatsApp with structured text
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentName || !formData.phoneNumber || !formData.parentName) {
      alert("Please fill in the required fields so we can customize your demo class!");
      return;
    }

    const compiledMessage = `*NEW TRIAL DEMO RESERVATION* 🎓\n\n` +
      `👤 *Parent Name:* ${formData.parentName}\n` +
      `👶 *Student Name:* ${formData.studentName}\n` +
      `📈 *Standard/Class:* ${formData.standard}\n` +
      `📚 *Subjects Needed:* ${formData.subject}\n` +
      `📞 *Phone Number:* ${formData.phoneNumber}\n` +
      `🏠 *Learning Preference:* ${formData.locationPreference}\n\n` +
      `_Hello Kothrud Home Tuition Academy, I have filled out the inquiry form on your website. Please check our details above and propose a suitable date & time for our Free Home Trial Lesson._`;

    setFormSubmitted(true);
    setTimeout(() => {
      window.open(getWhatsAppURL(compiledMessage), '_blank');
      setFormSubmitted(false);
    }, 8000);
  };

  // Reset form inputs
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Subject icon finder helper
  const getCourseIcon = (id: string) => {
    switch(id) {
      case 'kindergarten': return <Sparkles className="w-6 h-6 text-yellow-500" />;
      case 'primary-school': return <BookOpen className="w-6 h-6 text-blue-500" />;
      case 'middle-school': return <GraduationCap className="w-6 h-6 text-indigo-500" />;
      case 'phonics-training': return <Volume2 className="w-6 h-6 text-emerald-500" />;
      case 'handwriting-improvement': return <PenTool className="w-6 h-6 text-sky-500" />;
      case 'spoken-english-personality': return <Users className="w-6 h-6 text-fuchsia-500" />;
      case 'drawing-classes': return <Compass className="w-6 h-6 text-amber-500" />;
      case 'coding-computer': return <Laptop className="w-6 h-6 text-violet-500" />;
      case 'creative-activities': return <BrainCircuit className="w-6 h-6 text-pink-500" />;
      default: return <Sparkles className="w-6 h-6 text-brand-primary" />;
    }
  };

  // Convert generic icon string to actual Lucide component
  const getSellingPointIcon = (iconName: string) => {
    switch (iconName) {
      case 'Award': return <Award className="w-7 h-7 text-amber-500" />;
      case 'UserCheck': return <UserCheck className="w-7 h-7 text-blue-500" />;
      case 'Users': return <Users className="w-7 h-7 text-indigo-500" />;
      case 'IndianRupee': return <IndianRupee className="w-7 h-7 text-emerald-500" />;
      case 'TrendingUp': return <TrendingUp className="w-7 h-7 text-rose-500" />;
      case 'CalendarCheck': return <CalendarCheck className="w-7 h-7 text-sky-500" />;
      case 'Sparkles': return <Sparkles className="w-7 h-7 text-amber-400 animate-pulse" />;
      case 'MapPin': return <MapPin className="w-7 h-7 text-rose-500 animate-bounce" />;
      default: return <Sparkles className="w-7 h-7 text-brand-primary" />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-bg font-sans text-brand-dark selection:bg-brand-secondary/30 selection:text-brand-primary antialiased relative">
      
      {/* LOCAL SEO SCHEMA STATEMENTS - HIDDEN IN UI BUT RAW AND CRAWLABLE FOR AEO & GOOGLE AI OVERVIEWS */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "EducationalOrganization",
          "name": "Kothrud Home Tuition Academy",
          "description": "Premium personal home tuition and small batch tutoring academy based in Bhusari Colony, Kothrud, Pune. Specialize in nursery to 8th standard CBSE, ICSE, SSC boards, Phonics, Drawing and Computer basics.",
          "url": "https://ais-pre-igfxq7vqje7d4tfr3sdenf-897312658363.asia-east1.run.app",
          "telephone": "+919172415302",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Bhusari Colony, Paud Road, Kothrud",
            "addressLocality": "Pune",
            "addressRegion": "Maharashtra",
            "postalCode": "411038",
            "addressCountry": "IN"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": "18.5074",
            "longitude": "73.8077"
          },
          "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday",
              "Sunday"
            ],
            "opens": "08:00",
            "closes": "21:00"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "142"
          }
        })}
      </script>

      {/* STICKY TOP HUD BAR */}
      <div className="bg-brand-primary text-white text-xs py-2 px-4 sticky top-0 z-50 shadow-sm font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-1.5 md:gap-4 flex-wrap justify-center text-center">
            <span className="bg-white/20 px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider">Pune's Best Tutor</span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-yellow-300" /> Bhusari Colony & Kothrud, Pune, Maharashtra
            </span>
            <span className="hidden md:inline-flex items-center gap-1 text-white/90">
              <Clock className="w-3.5 h-3.5 text-yellow-300 animate-pulse" /> Free Home Demo Classes! Limited Slot Booking Left
            </span>
          </div>
          <button 
            id="bar-demo-btn"
            onClick={() => handleDirectCTA('demo')} 
            className="hidden sm:inline-flex items-center gap-1 cursor-pointer bg-brand-accent hover:bg-yellow-500 text-brand-dark px-3 py-1 rounded-md text-xs font-bold transition-transform active:scale-95"
          >
            Get Free Demo
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* HEADER NAVIGATION */}
      <header className="sticky top-[32px] sm:top-[36px] z-40 bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-100 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo Brand */}
          <a href="#" className="flex items-center gap-2 group">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-brand-primary via-brand-secondary to-indigo-950 flex items-center justify-center text-white shadow-md shadow-indigo-650/15 group-hover:scale-105 transition-transform duration-300">
              <GraduationCap className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <span className="block text-lg font-black tracking-tight bg-gradient-to-r from-brand-primary via-brand-secondary to-brand-primary bg-clip-text text-transparent">
                KOTHRUD HOME
              </span>
              <span className="block text-[10px] font-black text-slate-500 tracking-widest uppercase">
                Tuition Academy
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-8 font-semibold text-slate-600 text-sm">
            <a href="#why-choose-us" className="hover:text-brand-secondary transition-colors py-2 relative group">
              Why Choose Us
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-secondary transition-all group-hover:w-full"></span>
            </a>
            <a href="#courses" className="hover:text-brand-secondary transition-colors py-2 relative group">
              Programs Offered
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-secondary transition-all group-hover:w-full"></span>
            </a>
            <a href="#methodology" className="hover:text-brand-secondary transition-colors py-2 relative group">
              Teaching Process
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-secondary transition-all group-hover:w-full"></span>
            </a>
            <a href="#testimonials" className="hover:text-brand-secondary transition-colors py-2 relative group">
              Parent Reviews
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-secondary transition-all group-hover:w-full"></span>
            </a>
            <a href="#faq" className="hover:text-brand-secondary transition-colors py-2 relative group">
              FAQs
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-secondary transition-all group-hover:w-full"></span>
            </a>
            <a href="#contact" className="hover:text-brand-secondary transition-colors py-2 relative group">
              Location & Contact
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-secondary transition-all group-hover:w-full"></span>
            </a>
          </nav>

          {/* Desktop Right CTA Action buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <button 
              id="header-consult-btn"
              onClick={() => handleDirectCTA('consultation')}
              className="text-brand-primary hover:text-brand-secondary bg-slate-50 hover:bg-slate-100 px-4 py-2.5 rounded-lg text-xs font-black transition-all border border-slate-200/80 shadow-xs active:scale-95 cursor-pointer uppercase tracking-wider"
            >
              Get Free Consultation
            </button>
            <button 
              id="header-whatsapp-btn"
              onClick={() => handleDirectCTA('demo')}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-5 py-3 rounded-lg flex items-center gap-2 shadow-sm active:scale-95 transition-all shadow-emerald-600/10 cursor-pointer uppercase tracking-wider"
            >
              <Phone className="w-4 h-4 fill-current" />
              Book Free Demo
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <div className="flex items-center lg:hidden gap-2">
            <button 
              id="mobile-quick-wa-btn"
              onClick={() => handleDirectCTA('demo')}
              className="bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm active:scale-95"
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              Book Demo
            </button>
            <button 
              id="mobile-menu-hamburger"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-slate-700 rounded-lg bg-slate-100 hover:bg-slate-200 focus:outline-none transition-colors ml-1"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer Overlay */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
              className="lg:hidden bg-white border-t border-slate-100 overflow-hidden shadow-lg"
            >
              <div className="px-5 py-6 space-y-4">
                <nav className="flex flex-col space-y-3 font-medium text-slate-700">
                  <a 
                    href="#why-choose-us" 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="hover:text-brand-primary p-2 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Why Choose Us
                  </a>
                  <a 
                    href="#courses" 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="hover:text-brand-primary p-2 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Programs Offered
                  </a>
                  <a 
                    href="#methodology" 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="hover:text-brand-primary p-2 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Teaching Process
                  </a>
                  <a 
                    href="#testimonials" 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="hover:text-brand-primary p-2 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Parent Reviews
                  </a>
                  <a 
                    href="#faq" 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="hover:text-brand-primary p-2 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    FAQs
                  </a>
                  <a 
                    href="#contact" 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="hover:text-brand-primary p-2 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Location & Contact
                  </a>
                </nav>
                
                <div className="pt-4 border-t border-slate-100 flex flex-col gap-3">
                  <button 
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      handleDirectCTA('consultation');
                    }}
                    className="w-full text-center bg-slate-100 hover:bg-slate-200 text-slate-900 py-3 rounded-lg font-black text-xs uppercase tracking-wider transition-all"
                  >
                    Get Free Consultation
                  </button>
                  <button 
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      handleDirectCTA('demo');
                    }}
                    className="w-full text-center bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-lg font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md shadow-emerald-600/15"
                  >
                    <Phone className="w-4 h-4 fill-current" />
                    Book Free Demo Class
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* DYNAMIC REAL-TIME SOCIAL PROOF TOAST NOTIFICATION */}
      <AnimatePresence>
        {bookingToast.visible && (
          <motion.div 
            initial={{ opacity: 0, y: 40, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
            className="fixed bottom-24 left-4 z-50 max-w-sm w-[90%] sm:w-auto p-4 rounded-xl shadow-xl border border-blue-100 bg-white/95 backdrop-blur-md flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-brand-primary shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 leading-snug">Demo Booked!</p>
              <p className="text-[11px] font-medium text-slate-500 mt-0.5">{bookingToast.message}</p>
            </div>
            <button 
              onClick={() => setBookingToast(prev => ({...prev, visible: false}))}
              className="text-slate-400 hover:text-slate-600 ml-auto shrink-0 p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FIXED FLOATING WHATSAPP BUTTON WITH PULSE WAVE */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 pointer-events-none">
        
        {/* Playful Floating Message Box */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.8, x: 20 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          transition={{ delay: 3, duration: 0.5 }}
          className="bg-white px-3 py-2 rounded-xl text-xs font-bold shadow-lg border border-slate-100 flex items-center gap-2 pointer-events-auto cursor-pointer max-w-xs relative hover:-translate-y-1 transition-transform"
          onClick={() => handleDirectCTA('demo')}
        >
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-slate-700">Chat with Senior Teacher!</span>
          <div className="absolute right-6 -bottom-1.5 w-3 h-3 bg-white border-r border-b border-slate-100 rotate-45"></div>
        </motion.div>

        {/* The Action Circle Button */}
        <button
          id="sticky-whatsapp-floating"
          onClick={() => handleDirectCTA('demo')}
          className="pointer-events-auto cursor-pointer w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-xl shadow-emerald-500/30 transition-all hover:scale-110 active:scale-95 group relative"
          title="Instant Help on WhatsApp"
        >
          {/* Pulsing ring */}
          <span className="absolute inset-0 rounded-full bg-emerald-400/40 animate-ping group-hover:animate-none opacity-75"></span>
          <Phone className="w-7 h-7 fill-current relative z-10" />
        </button>
      </div>

      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-20 md:py-24 bg-gradient-to-b from-[#EBF5F2]/60 via-[#FCFAF4] to-white">
        
        {/* Floating decoration elements mapping to high context Pune, Maharashtra, India learning */}
        <div className="absolute top-1/4 left-1/10 w-16 h-16 bg-brand-secondary/10 rounded-full animate-float opacity-70 border border-brand-secondary/20 pointer-events-none"></div>
        <div className="absolute bottom-1/4 right-1/10 w-24 h-24 bg-brand-accent/10 rounded-full animate-float-delayed opacity-85 border border-brand-accent/20 pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Hero Text & Actions */}
            <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
              
              {/* Trust Badge Pill */}
              <div className="inline-flex items-center gap-2 bg-[#EBF5F2] border border-brand-secondary/20 px-3.5 py-1.5 rounded-full shadow-xs">
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-secondary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-brand-secondary"></span>
                </span>
                <span className="text-[10px] sm:text-xs font-black text-brand-primary tracking-widest uppercase font-mono">
                  #1 HOME TUITION IN KOTHRUD, PUNE
                </span>
              </div>
 
              {/* Main Headline */}
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-5xl font-serif text-brand-primary leading-[1.12] font-black">
                Expert Home Tuition in <span className="bg-gradient-to-r from-brand-primary via-brand-secondary to-[#052118] bg-clip-text text-transparent underline decoration-brand-accent/50 decoration-4">Kothrud</span> – Personalized Learning for <span className="italic font-normal text-brand-secondary">Academic Excellence</span>
              </h1>

              {/* Explicit Subhead */}
              <p className="text-base sm:text-lg text-slate-700 font-medium leading-relaxed max-w-2xl mx-auto lg:mx-0">
                20+ Years of Teaching Experience <span className="text-brand-accent">|</span> One-to-One Home Tuition <span className="text-brand-accent">|</span> Small Batch Classes <span className="text-brand-accent">|</span> Affordable Fees
              </p>

              {/* Key Quick Bullet points */}
              <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto lg:mx-0 pt-2">
                <div className="flex items-start gap-2 text-left">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-black text-slate-900">SSC, CBSE & ICSE Teams</p>
                    <p className="text-[11px] text-slate-500 font-medium">Nursery to 8th Standard</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 text-left">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-black text-slate-900">Bhusari Colony Center</p>
                    <p className="text-[11px] text-slate-500 font-medium">Or we visit your Pune residence</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 text-left">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-black text-slate-900">Phonics & Handwriting</p>
                    <p className="text-[11px] text-slate-500 font-medium">Skill Development included</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 text-left">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-black text-slate-900">Child-Friendly Methods</p>
                    <p className="text-[11px] text-slate-500 font-medium">No stressful rote learning</p>
                  </div>
                </div>
              </div>

              {/* Conversion Actions Group */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-3">
                <button
                  onClick={() => handleDirectCTA('demo')}
                  className="w-full sm:w-auto bg-gradient-to-r from-brand-primary via-brand-secondary to-indigo-900 hover:from-brand-secondary hover:to-brand-primary text-white font-black px-8 py-4.5 rounded-xl shadow-lg shadow-indigo-650/20 active:scale-95 transition-all text-xs sm:text-sm flex items-center justify-center gap-2.5 cursor-pointer leading-none uppercase tracking-wider"
                >
                  <CalendarCheck className="w-5 h-5" />
                  Book Free Demo Class
                </button>
                <button
                  onClick={() => handleDirectCTA('default')}
                  className="w-full sm:w-auto bg-slate-900 hover:bg-slate-955 text-white font-black px-8 py-4.5 rounded-xl shadow-lg active:scale-95 transition-all text-xs sm:text-sm flex items-center justify-center gap-2.5 cursor-pointer border border-slate-700 leading-none uppercase tracking-wider"
                >
                  <Phone className="w-5 h-5 fill-current" />
                  WhatsApp Now
                </button>
              </div>

              {/* Real-time trust validation */}
              <div className="flex items-center justify-center lg:justify-start gap-6 pt-4 border-t border-slate-200/60 w-fit mx-auto lg:mx-0">
                <div>
                  <p className="text-xl sm:text-2xl font-black text-slate-900">20+ Yrs</p>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-0.5">Teaching Experience</p>
                </div>
                <div className="h-8 w-px bg-slate-200"></div>
                <div>
                  <p className="text-xl sm:text-2xl font-black text-slate-900">1,500+</p>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-0.5">Students Guided</p>
                </div>
                <div className="h-8 w-px bg-slate-200"></div>
                <div>
                  <div className="flex items-center gap-0.5">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  </div>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">4.9/5 Parent Rating</p>
                </div>
              </div>

            </div>

            {/* Hero Visual Mockup: Interactive Vector Graphic of Teacher and Pupil */}
            <div className="lg:col-span-5 relative mt-6 lg:mt-0">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                
                {/* Visual Glow */}
                <div className="absolute inset-x-0 top-0 -translate-y-12 h-72 w-72 rounded-full bg-gradient-to-tr from-blue-300 to-indigo-300 opacity-20 blur-3xl mx-auto"></div>

                {/* Main Premium Card Visual */}
                <div className="relative bg-white p-6 rounded-3xl shadow-xl border border-slate-100 flex flex-col gap-6">
                  
                  {/* Visual Header */}
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase font-mono">Bhusari Colony Study Group</span>
                  </div>

                  {/* Creative Learning Scene Block */}
                  <div className="space-y-4">
                    
                    {/* Visual Card 1: Senior Teacher Mentoring */}
                    <div className="bg-white p-4 rounded-2xl border border-slate-150 flex items-center gap-4 relative overflow-hidden group hover:shadow-md transition-shadow">
                      <div className="absolute right-0 top-0 w-24 h-24 bg-brand-secondary/5 rounded-full -translate-x-4 -translate-y-4"></div>
                      <div className="w-12 h-12 bg-indigo-50 text-brand-primary rounded-xl flex items-center justify-center shrink-0 font-black text-lg shadow-sm border border-indigo-100">
                        20+
                      </div>
                      <div>
                        <span className="bg-amber-100 text-amber-900 text-[9px] font-black px-2.5 py-0.5 rounded-full tracking-wider uppercase">Senior Teacher</span>
                        <h4 className="text-sm font-black text-brand-primary mt-1">Highly Experienced Pedagogy</h4>
                        <p className="text-xs text-slate-600 font-medium">Specializes in weak areas recovery and handwriting pacing</p>
                      </div>
                    </div>

                    {/* Interactive Active Worksheets Graphic */}
                    <div className="bg-gradient-to-r from-brand-primary via-indigo-950 to-brand-primary p-5 rounded-2xl text-white relative shadow-md border border-indigo-900">
                      <div className="absolute top-2 right-2 flex gap-1">
                        <Sparkles className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '4s' }} />
                      </div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-indigo-200 font-mono">Student Milestones</p>
                      <h4 className="text-lg font-black mt-1">One-to-One Growth Curve</h4>
                      
                      {/* Interactive Visual Graph Lines */}
                      <div className="flex items-end justify-between h-14 mt-4 select-none pb-1 relative">
                        <div className="absolute inset-x-0 bottom-1 border-b border-white/20 border-dashed"></div>
                        <div className="w-[12%] bg-white/20 rounded-t h-4 transition-all hover:bg-white/40" title="Week 1: Base assessment"></div>
                        <div className="w-[12%] bg-white/30 rounded-t h-6 transition-all hover:bg-white/40" title="Week 2: Plan initialization"></div>
                        <div className="w-[12%] bg-white/40 rounded-t h-9 transition-all hover:bg-white/50" title="Week 3: Visual tools training"></div>
                        <div className="w-[12%] bg-white/60 rounded-t h-10 transition-all hover:bg-white/85" title="Week 4: Performance feedback"></div>
                        <div className="w-[12%] bg-white/80 rounded-t h-12 transition-all hover:bg-white" title="Week 5: Speed boost"></div>
                        <div className="w-[12%] bg-amber-400 rounded-t h-14 transition-all animate-bounce" title="Week 6: Excel rank!"></div>
                        <div className="w-[12%] bg-brand-secondary rounded-t h-16" title="Target: A+ grade"></div>
                      </div>
                      <div className="flex justify-between items-center text-[10px] text-indigo-200 mt-2 font-medium">
                        <span>Baseline Assessed</span>
                        <span className="text-amber-300 font-bold">Concept Built (+92%)</span>
                      </div>
                    </div>

                    {/* Quick Interactive Selector */}
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-slate-50 p-2.5 rounded-xl text-center border border-slate-100">
                        <p className="text-xs font-bold text-slate-800">100%</p>
                        <p className="text-[9px] text-slate-500 mt-0.5">Flexible Timings</p>
                      </div>
                      <div className="bg-slate-50 p-2.5 rounded-xl text-center border border-slate-100">
                        <p className="text-xs font-bold text-slate-800">SSC/CBSE</p>
                        <p className="text-[9px] text-slate-500 mt-0.5">Syllabus Aligned</p>
                      </div>
                      <div className="bg-slate-50 p-2.5 rounded-xl text-center border border-slate-100">
                        <p className="text-xs font-bold text-slate-800">1:1 Focus</p>
                        <p className="text-[9px] text-slate-500 mt-0.5">At Home/Batch</p>
                      </div>
                    </div>

                  </div>

                  {/* Visual Footer Promo Label */}
                  <div className="bg-emerald-50/70 border border-emerald-100 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-emerald-800">
                    <span className="flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-emerald-600 shrink-0" />
                      Free 1-Hour Home Assessment Demo!
                    </span>
                    <button 
                      onClick={() => handleDirectCTA('demo')}
                      className="bg-emerald-600 text-white rounded px-2.5 py-1 text-[10px] uppercase font-mono tracking-widest hover:bg-emerald-700 pointer-events-auto cursor-pointer"
                    >
                      CLAIM
                    </button>
                  </div>

                </div>

                {/* Secondary absolute indicators */}
                <div className="absolute -bottom-6 -left-6 bg-slate-900 text-white p-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border border-slate-800 animate-float">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white shrink-0">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold font-mono">AFFORDABLE RATES</p>
                    <p className="text-[10px] text-slate-300">No high deposits charged</p>
                  </div>
                </div>

                <div className="absolute -top-4 -right-4 bg-white p-3 rounded-2xl shadow-lg border border-slate-100 flex items-center gap-2 animate-float-delayed">
                  <div className="w-2 rounded bg-amber-500 h-8"></div>
                  <div>
                    <p className="text-xs font-extrabold text-brand-dark">Grade Booster</p>
                    <div className="flex gap-0.5 mt-0.5">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    </div>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* WHY CHOOSE US SECTION */}
      <section id="why-choose-us" className="py-20 bg-white scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <motion.div 
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto space-y-4"
          >
            <span className="text-brand-primary text-xs font-black tracking-widest uppercase font-mono bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100">
              CORE ADVANTAGES
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-brand-primary tracking-tight">
              Why Kothrud Home Tuition Academy is Highly Trusted by Parents
            </h2>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              Providing personalized attention in Bhusari Colony & surrounding Pune areas to elevate your child’s learning confidence, conceptual base, and handwriting speed.
            </p>
          </motion.div>

          {/* Premium Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
            {SELLING_POINTS.map((point, index) => (
              <motion.div
                key={point.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className="bg-brand-bg rounded-2xl p-6 border border-slate-200/60 hover:border-brand-secondary/30 hover:shadow-xl transition-all duration-300 group flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-sm border border-slate-100 group-hover:scale-110 group-hover:bg-indigo-50 transition-all">
                    {getSellingPointIcon(point.iconName)}
                  </div>
                  <h3 className="text-base font-black text-brand-primary group-hover:text-brand-secondary transition-colors">
                    {point.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                    {point.description}
                  </p>
                </div>
                
                {/* Visual action cue */}
                <div className="pt-4 mt-4 border-t border-slate-200/40 flex items-center justify-between">
                  <span className="text-[10px] font-black text-brand-secondary uppercase font-mono tracking-wider">Verified Service</span>
                  <ChevronRightSmall />
                </div>
              </motion.div>
            ))}
          </div>

        </div>
      </section>

      {/* QUICK STATS COUNTER STRIP */}
      <section className="bg-gradient-to-r from-brand-primary via-indigo-950 to-brand-primary py-12 text-white relative overflow-hidden border-y border-[#2E1A47]/40">
        
        {/* Abstract background graphics */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-brand-secondary/15 to-transparent pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            
            <div className="space-y-1">
              <p className="text-2xl sm:text-4xl font-extrabold text-amber-400 font-mono">20+ Years</p>
              <p className="text-[10px] sm:text-xs font-black text-slate-300 tracking-widest uppercase">Teaching Pedagogy</p>
            </div>

            <div className="space-y-1">
              <p className="text-2xl sm:text-4xl font-extrabold text-white font-mono">1500+</p>
              <p className="text-[10px] sm:text-xs font-black text-slate-300 tracking-widest uppercase">Pupils Mentored</p>
            </div>

            <div className="space-y-1">
              <p className="text-2xl sm:text-4xl font-extrabold text-amber-400 font-mono">98%</p>
              <p className="text-[10px] sm:text-xs font-black text-slate-300 tracking-widest uppercase">Score Gain Guarantee</p>
            </div>

            <div className="space-y-1">
              <p className="text-2xl sm:text-4xl font-extrabold text-[#10B981] font-mono">100%</p>
              <p className="text-[10px] sm:text-xs font-black text-slate-300 tracking-widest uppercase">Weekly Worksheets</p>
            </div>

          </div>
        </div>
      </section>

      {/* PROGRAMS & COURSES SECTION */}
      <section id="courses" className="py-20 bg-brand-bg scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <span className="text-brand-primary text-xs font-black tracking-widest uppercase font-mono bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100">
              ACADEMIC WINGS & SKILLS
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-brand-primary tracking-tight">
              Class Room Programs & Custom Home Curriculums
            </h2>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              Each session incorporates localized Maharashtra board SSC, CBSE, or ICSE standard guidelines, supported by real-life activities and continuous weekly test tracking.
            </p>

            {/* Premium Navigation Tabs */}
            <div className="inline-flex p-1.5 rounded-xl bg-white border border-slate-205 shadow-xs mt-8">
              <button
                onClick={() => setCourseTab('academic')}
                className={`px-4 sm:px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  courseTab === 'academic' 
                    ? 'bg-brand-primary text-white shadow' 
                    : 'text-slate-600 hover:text-brand-primary bg-transparent'
                }`}
              >
                🎓 Academic Tuition (Nursery - 8th)
              </button>
              <button
                onClick={() => setCourseTab('skill')}
                className={`px-4 sm:px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  courseTab === 'skill' 
                    ? 'bg-brand-primary text-white shadow' 
                    : 'text-slate-600 hover:text-brand-primary bg-transparent'
                }`}
              >
                🎨 Skill Development Classes
              </button>
            </div>
          </div>

          {/* Courses Display Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            
            {courseTab === 'academic' ? (
              // Academic Cards
              ACADEMIC_COURSES.map((course, idx) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                  className="bg-white rounded-2xl border border-slate-200/80 hover:border-brand-secondary/35 hover:shadow-xl transition-all duration-300 p-6 flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center border border-indigo-100/50">
                        {getCourseIcon(course.id)}
                      </div>
                      <span className="bg-indigo-50 text-indigo-700 text-[10px] font-black px-2.5 py-1 rounded-full tracking-wider font-mono">
                        {course.targetAges}
                      </span>
                    </div>

                    <h3 className="text-lg font-black text-brand-primary">{course.title}</h3>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">{course.description}</p>
                    
                    {/* Highlights list */}
                    <div className="space-y-2 pt-2">
                      <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest font-mono">Special Focus subjects:</p>
                      <ul className="grid grid-cols-2 gap-2 text-xs text-slate-700 font-medium">
                        {course.highlights.map((highlight, index) => (
                          <li key={index} className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-secondary shrink-0"></span>
                            <span className="truncate">{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                  </div>

                  {/* WhatsApp Action */}
                  <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col gap-2.5">
                    <button
                      onClick={() => handleDirectCTA('default', course.title)}
                      className="w-full text-center bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3 rounded-lg text-xs flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer uppercase tracking-wider"
                    >
                      <Phone className="w-4 h-4 fill-current animate-pulse" />
                      Enquire on WhatsApp
                    </button>
                    <p className="text-center text-[10px] text-slate-500 font-bold">
                      🇮🇳 Ideal for SSC / CBSE / ICSE boards
                    </p>
                  </div>
                </motion.div>
              ))
            ) : (
              // Skill Program Cards
              SKILL_PROGRAMS.map((course, idx) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                  className="bg-white rounded-2xl border border-slate-200/80 hover:border-brand-secondary/35 hover:shadow-xl transition-all duration-300 p-6 flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center border border-amber-100/55">
                        {getCourseIcon(course.id)}
                      </div>
                      <span className="bg-amber-100 text-amber-955 text-[10px] font-black px-2.5 py-1 rounded-full tracking-wider font-mono">
                        {course.targetAges}
                      </span>
                    </div>

                    <h3 className="text-lg font-black text-brand-primary">{course.title}</h3>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">{course.description}</p>
                    
                    {/* Highlights list */}
                    <div className="space-y-2 pt-2">
                      <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest font-mono">Curriculum targets:</p>
                      <ul className="grid grid-cols-2 gap-2 text-xs text-slate-700 font-medium">
                        {course.highlights.map((highlight, index) => (
                          <li key={index} className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-accent shrink-0"></span>
                            <span className="truncate">{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                  </div>

                  {/* WhatsApp Action */}
                  <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col gap-2.5">
                    <button
                      onClick={() => handleDirectCTA('default', course.title)}
                      className="w-full text-center bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3 rounded-lg text-xs flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer uppercase tracking-wider"
                    >
                      <Phone className="w-4 h-4 fill-current animate-pulse" />
                      Enquire on WhatsApp
                    </button>
                    <p className="text-center text-[10px] text-slate-500 font-bold">
                      🧠 Creative learning activities mapped
                    </p>
                  </div>
                </motion.div>
              ))
            )}

          </div>

          {/* Prompt Section Box */}
          <div className="bg-white border border-slate-205 rounded-3xl p-6 sm:p-8 mt-12 grid grid-cols-1 md:grid-cols-4 gap-6 items-center shadow-xs">
            <div className="md:col-span-3 space-y-2">
              <span className="bg-amber-100 text-amber-900 text-[9px] font-black px-2.5 py-1 rounded-full tracking-wider uppercase font-mono">Customization Available</span>
              <h3 className="text-lg font-black text-brand-primary">Need tuition in a different subject or custom combined program?</h3>
              <p className="text-xs sm:text-sm text-slate-600 font-medium leading-relaxed">
                Connect directly with us on WhatsApp. We design modular learning paths matching school syllabus timelines, homework needs, and speed goals.
              </p>
            </div>
            <div className="md:col-span-1 text-right flex justify-start md:justify-end">
              <button
                onClick={() => handleDirectCTA('default', 'Premium Customized Home learning')}
                className="w-full md:w-auto text-center cursor-pointer bg-brand-primary hover:bg-indigo-900 text-white font-black px-6 py-3.5 rounded-xl shadow text-xs uppercase tracking-wider whitespace-nowrap active:scale-95 transition-colors border border-brand-primary/20"
              >
                Join Batch Now
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* TEACHING METHODOLOGY SECTION */}
      <section id="methodology" className="py-20 bg-white scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <motion.div 
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto space-y-4"
          >
            <span className="text-brand-primary text-xs font-black tracking-widest uppercase font-mono bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100">
              METHODICAL EXCELLENCE
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-brand-primary tracking-tight">
              Our 6-Step Result-Oriented Teaching Process
            </h2>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              A meticulously structured roadmap designed to identify children’s underlying challenges, optimize their schedule, and yield permanent improvement in confidence and skills.
            </p>
          </motion.div>

          {/* Timeline Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12 relative">
            {METHODOLOGY_STEPS.map((step, index) => (
              <motion.div 
                key={step.stepNumber}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.45, delay: index * 0.08 }}
                className="bg-brand-bg rounded-2xl p-6 border border-slate-200/85 hover:border-brand-secondary/35 hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-center gap-4 border-b border-slate-200/40 pb-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-brand-primary to-brand-secondary text-white flex items-center justify-center font-mono font-black text-lg shadow-sm border border-indigo-900/10">
                    {step.stepNumber}
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-brand-primary">
                    {step.title}
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>

        </div>
      </section>

      {/* INTERACTIVE DIAGNOSTIC HUB */}
      <InteractionHub />

      {/* EXCITING ENGAGING FEATURE: TUTOR MATCHMAKER & BUDGET ESTIMATOR */}
      <section id="matchmaker" className="py-20 bg-brand-bg border-y border-slate-205 scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
            <span className="text-brand-primary text-xs font-black tracking-widest uppercase font-mono bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100">
              ENGAGING TOOL
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-brand-primary tracking-tight">
              Interactive Tutor Matchmaker & Budget Planner
            </h2>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              Configure your children's custom requirements below. Instantly see recommended verified tutor profiles and protective monthly estimates based on Pune tuition trends.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mt-8">
            
            {/* Planner Form controls on left */}
            <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col justify-between space-y-6">
              
              <div className="space-y-6">
                
                {/* 1. Student Standard Category */}
                <div className="space-y-3">
                  <label className="text-xs font-black text-brand-primary uppercase tracking-wider block font-mono">1. Select Child's Grade Wing</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setMatchGrade('early')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        matchGrade === 'early'
                          ? 'bg-brand-primary border-brand-primary text-white shadow-md font-black'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-350 hover:bg-slate-100/50 font-semibold'
                      } text-xs`}
                    >
                      👶 Early Years <br/><span className="text-[10px] opacity-85 font-bold">(Nursery-KG)</span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => setMatchGrade('primary')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        matchGrade === 'primary'
                          ? 'bg-brand-primary border-brand-primary text-white shadow-md font-black'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-350 hover:bg-slate-100/50 font-semibold'
                      } text-xs`}
                    >
                      🏫 Primary <br/><span className="text-[10px] opacity-85 font-bold">(1st-4th Std)</span>
                    </button>
 
                    <button
                      type="button"
                      onClick={() => setMatchGrade('middle')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        matchGrade === 'middle'
                          ? 'bg-brand-primary border-brand-primary text-white shadow-md font-black'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-350 hover:bg-slate-100/50 font-semibold'
                      } text-xs`}
                    >
                      🎓 Middle <br/><span className="text-[10px] opacity-85 font-bold">(5th-8th Std)</span>
                    </button>
 
                    <button
                      type="button"
                      onClick={() => setMatchGrade('skills')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        matchGrade === 'skills'
                          ? 'bg-brand-primary border-brand-primary text-white shadow-md font-black'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-350 hover:bg-slate-100/50 font-semibold'
                      } text-xs`}
                    >
                      🎨 Skill Wings <br/><span className="text-[10px] opacity-85 font-bold">(Phonics/Drawing)</span>
                    </button>
                  </div>
                </div>
 
                {/* 2. Class Mode Selection */}
                <div className="space-y-3">
                  <label className="text-xs font-black text-brand-primary uppercase tracking-wider block font-mono">2. Select Tuition Mode</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setMatchMode('home')}
                      className={`p-4 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                        matchMode === 'home'
                          ? 'border-brand-secondary bg-[#EBF5F2]/40 shadow-sm ring-1 ring-brand-secondary text-brand-primary'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <UserCheck className={`w-5 h-5 mt-0.5 shrink-0 ${matchMode === 'home' ? 'text-brand-secondary' : 'text-slate-500'}`} />
                      <div>
                        <p className="text-xs font-black text-brand-primary">One-to-One Home Tuition</p>
                        <p className="text-[10px] text-slate-600 mt-0.5 font-medium">Tutor visits your home. Highly customized pacing.</p>
                      </div>
                    </button>
 
                    <button
                      type="button"
                      onClick={() => setMatchMode('academy')}
                      className={`p-4 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                        matchMode === 'academy'
                          ? 'border-brand-secondary bg-[#EBF5F2]/40 shadow-sm ring-1 ring-brand-secondary text-brand-primary'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <Users className={`w-5 h-5 mt-0.5 shrink-0 ${matchMode === 'academy' ? 'text-brand-secondary' : 'text-slate-500'}`} />
                      <div>
                        <p className="text-xs font-black text-brand-primary">Small Batch Center Class</p>
                        <p className="text-[10px] text-slate-600 mt-0.5 font-medium">Taught at physical Bhusari Colony academy branch.</p>
                      </div>
                    </button>
                  </div>
                </div>
 
                {/* 3. Session Frequency Slider/Clicker */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-black text-brand-primary uppercase tracking-wider block font-mono">3. Session Days per Week</label>
                    <span className="text-xs font-black text-brand-secondary bg-[#EBF5F2] px-2.5 py-1 rounded-md font-mono border border-brand-secondary/20">{matchFrequency} Session days</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {[2, 3, 5].map((freq) => (
                      <button
                        key={freq}
                        type="button"
                        onClick={() => setMatchFrequency(freq)}
                        className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                          matchFrequency === freq
                            ? 'bg-brand-secondary border-brand-secondary text-white shadow-sm font-black'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300 font-semibold'
                        } text-xs`}
                      >
                        {freq === 2 ? '⚡ Weekend (2 Days)' : freq === 3 ? '🗓️ Alternate (3 Days)' : '🔥 Regular (5 Days)'}
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* Secure note */}
              <div className="bg-[#EBF5F2]/40 p-4 rounded-2xl border border-brand-secondary/15 text-[11px] text-slate-650 font-medium leading-relaxed">
                📢 <span className="font-black text-brand-primary font-serif">Maharashtra Syllabi & Board Standards covered:</span> We map strictly against state board SSC timelines, custom CBSE textbooks, or ICSE reference materials for Bhusari Colony families.
              </div>

            </div>

            {/* Matchmaker result card on the right (Highly interactive, with simulated Live Tutor profile match) */}
            <div className="lg:col-span-5 bg-gradient-to-b from-[#092E21] to-[#041E15] text-white p-6 sm:p-8 rounded-3xl shadow-xl flex flex-col justify-between space-y-6 border border-[#0A856D]/20">
              
              <div className="space-y-6">
                
                {/* Result header */}
                <div className="flex justify-between items-start">
                  <div>
                    <span className="bg-emerald-600/30 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/20 font-mono">
                      LIVE PROFILE MATCH
                    </span>
                    <h3 className="text-lg font-black text-white mt-1.5 font-serif">Matched Specialty Tutor</h3>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-brand-accent">
                    <Sparkles className="w-5 h-5 animate-pulse" />
                  </div>
                </div>

                {/* Tutor Profile Details (Dynamic) */}
                {(() => {
                  const { recommendedTutor } = calculateFees();
                  return (
                    <motion.div 
                      key={matchGrade}
                      initial={{ opacity: 0, x: 15 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-4"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-brand-secondary/35 text-emerald-300 flex items-center justify-center font-black text-lg border border-brand-secondary/30 shadow-inner">
                          {recommendedTutor.name.split(' ').map(n=>n[0]).join('')}
                        </div>
                        <div>
                          <p className="text-sm font-black text-white">{recommendedTutor.name}</p>
                          <p className="text-[10px] text-amber-400 font-bold">{recommendedTutor.badge}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
                        <div className="bg-white/[0.03] p-2 rounded-lg">
                          <span className="text-slate-400 block text-[9px] font-mono">EXPERIENCE</span>
                          <span className="font-bold text-white">{recommendedTutor.experience}</span>
                        </div>
                        <div className="bg-white/[0.03] p-2 rounded-lg">
                          <span className="text-slate-400 block text-[9px] font-mono">DEMO RATINGS</span>
                          <span className="font-bold text-emerald-400">{recommendedTutor.rating}</span>
                        </div>
                      </div>

                      <div className="bg-white/[0.02] p-3 rounded-lg border border-white/[0.04]">
                        <span className="text-slate-400 block text-[9px] font-mono mb-0.5">CORE DISCIPLINE</span>
                        <p className="text-xs text-slate-200 leading-relaxed font-medium">{recommendedTutor.specialty}</p>
                      </div>
                    </motion.div>
                  );
                })()}

                {/* Fee display */}
                {(() => {
                  const { hourlyRate, monthlyTotal } = calculateFees();
                  return (
                    <div className="border-t border-white/10 pt-6 space-y-3">
                      <div className="flex justify-between items-center text-xs text-slate-350">
                        <span>Estimated Hourly rate:</span>
                        <span className="font-mono font-bold text-white">~ ₹{hourlyRate} / hour</span>
                      </div>
                      
                      <div className="bg-white/5 rounded-2xl p-4 flex items-center justify-between border-2 border-dashed border-white/10">
                        <div>
                          <span className="text-[10px] text-slate-400 font-mono block">ESTIMATED ACCOUNTABLE BUDGET</span>
                          <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">₹{monthlyTotal.toLocaleString()}<span className="text-xs text-slate-300 font-normal">/month</span></span>
                        </div>
                      </div>
                    </div>
                  );
                })()}

              </div>

              {/* Action */}
              <div className="space-y-3">
                <button
                  type="button"
                  onClick={handleMatchmakerCTA}
                  className="w-full text-center bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-xl text-xs sm:text-sm shadow-lg flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer uppercase tracking-wider"
                >
                  <Phone className="w-4 h-4 fill-current text-white animate-bounce" />
                  Connect With Tutor on WhatsApp
                </button>
                <p className="text-center text-[10px] text-slate-300 font-medium">
                  ⚡ Absolute zero deposit required. 100% Free evaluation demo class!
                </p>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* BENEFIT / MEASURABLE OUTCOME SECTION */}
      <section className="py-20 bg-gradient-to-b from-brand-primary to-indigo-950 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.04] pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Explanatory text */}
            <div className="lg:col-span-6 space-y-6">
              <span className="text-amber-400 text-xs font-mono font-black tracking-widest uppercase">
                MEASURABLE OUTCOMES
              </span>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-white leading-tight">
                Our Students Don’t Just Study – They Truly Thrive
              </h2>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                By focusing on conceptual building and avoiding stressful rote memorization, we trigger rapid neural development in early age and middle school kids.
              </p>

              {/* Grid checklist */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/30">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Better Marks</h4>
                    <p className="text-xs text-slate-300">Continuous custom worksheets boost scores</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/30">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Improved Confidence</h4>
                    <p className="text-xs text-slate-300">Eliminates school stage fright</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/30">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Strong Fundamentals</h4>
                    <p className="text-xs text-slate-300">Crystal-clear conceptual understanding</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/30">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Better Soft Skills</h4>
                    <p className="text-xs text-slate-300">Advanced grammar and daily speaking fluency</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/30">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Improved Handwriting</h4>
                    <p className="text-xs text-slate-300">Neat, responsive, and swift cursive strokes</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/30">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Faster Learning Speed</h4>
                    <p className="text-xs text-slate-300">Cognitive development activities included</p>
                  </div>
                </div>

              </div>

              {/* Conversion call-out */}
              <div className="pt-6">
                <button
                  onClick={() => handleDirectCTA('demo')}
                  className="bg-brand-accent hover:bg-amber-600 text-white font-black px-6 py-3.5 rounded-xl transition-all cursor-pointer shadow-lg inline-flex items-center gap-2 active:scale-95 text-xs uppercase tracking-wider"
                >
                  <CalendarCheck className="w-4 h-4" />
                  Book A Trial Home Class Now
                </button>
              </div>

            </div>

            {/* Graphic Badge/Feature element on the right */}
            <div className="lg:col-span-6 flex justify-center">
              <div className="relative p-6 bg-white/10 rounded-3xl border border-white/10 shadow-2xl backdrop-blur-md max-w-sm w-full space-y-6">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-400"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-400"></div>
                </div>
                
                <h3 className="text-lg font-black text-white">Child Development Matrix</h3>
                <div className="space-y-4">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-black text-slate-200">
                      <span>Concept Clarity</span>
                      <span className="text-brand-accent">95%</span>
                    </div>
                    <div className="w-full bg-slate-800/80 rounded-full h-2">
                      <div className="bg-brand-accent h-2 rounded-full w-[95%]"></div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-black text-slate-200">
                      <span>Writing Legibility & Flow</span>
                      <span className="text-emerald-400">90%</span>
                    </div>
                    <div className="w-full bg-slate-800/80 rounded-full h-2">
                      <div className="bg-emerald-400 h-2 rounded-full w-[90%]"></div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-black text-slate-200">
                      <span>Self-study habits</span>
                      <span className="text-indigo-300">92%</span>
                    </div>
                    <div className="w-full bg-indigo-950/80 rounded-full h-2">
                      <div className="bg-indigo-400 h-2 rounded-full w-[92%]"></div>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-xs text-slate-200 text-center font-medium leading-relaxed">
                  "One-to-one home learning reduces classroom distraction by over <span className="text-white font-bold underline text-amber-300">80%</span>, allowing custom query clearance."
                </div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* PARENTAL TESTIMONIALS SECTION */}
      <section id="testimonials" className="py-20 bg-brand-bg scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <span className="text-brand-primary text-xs font-black tracking-widest uppercase font-mono bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100">
              TRUST VERIFICATION
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-brand-primary tracking-tight">
              Real Stories of Academic Transformation
            </h2>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              Hear directly from parents residing in Bhusari Colony, Karve Nagar, and Bavdhan whose children experienced tangible boosts in school grades and self-belief.
            </p>
          </div>

          {/* Testimonial Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {TESTIMONIALS.map((t) => (
              <motion.div
                key={t.id}
                whileHover={{ y: -8 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80 hover:border-brand-secondary/35 hover:shadow-xl transition-all duration-300 relative flex flex-col justify-between"
              >
                <div className="space-y-4">
                  {/* Rating Stars */}
                  <div className="flex gap-1">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-brand-accent text-brand-accent" />
                    ))}
                  </div>

                  {/* Quote Review */}
                  <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed italic">
                    "{t.review}"
                  </p>
                </div>

                {/* Patient Student Info Panel */}
                <div className="pt-6 mt-6 border-t border-slate-100 space-y-3">
                  <div className="flex justify-between items-center bg-indigo-50/50 px-3 py-2 rounded-xl text-xs font-black text-brand-primary border border-indigo-100/30">
                    <span>Outcome:</span>
                    <span className="text-brand-secondary">{t.result}</span>
                  </div>

                  <div>
                    <h4 className="text-sm font-black text-brand-primary">{t.parentName}</h4>
                    <p className="text-[11px] font-semibold text-slate-500">
                      Parent of {t.studentName} ({t.standard}) – {t.school}
                    </p>
                  </div>
                </div>

                {/* Tiny Floating Trust Icon */}
                <div className="absolute right-4 top-4">
                  <span className="text-[9px] bg-indigo-50 text-indigo-700 font-black font-mono px-2 py-0.5 rounded border border-indigo-100">Verified</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Call-to-action */}
          <div className="text-center mt-12 font-mono">
            <button
              onClick={() => handleDirectCTA('default', 'General Enquiry')}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black px-6 py-3.5 rounded-lg text-xs tracking-wider uppercase inline-flex items-center gap-2 transition-all cursor-pointer shadow active:scale-95"
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              Chat With Former Parent Case Studies
            </button>
          </div>

        </div>
      </section>

      {/* SEO & AEO OPTIMIZED FAQS (ACCORDION STYLE) */}
      <section id="faq" className="py-20 bg-white scroll-mt-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          
          {/* Section Header */}
          <div className="text-center space-y-4 mb-12">
            <span className="text-brand-primary text-xs font-mono font-black tracking-widest uppercase bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100">
              LEARNING GUIDANCE (SEO & AEO)
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-brand-primary tracking-tight">
              Frequently Asked Questions (FAQ)
            </h2>
            <p className="text-sm text-slate-600 font-medium">
              Clear, conversational answers structured to rank in Gemini, ChatGPT, and popular search tools for families seeking private tutoring in Pune.
            </p>
          </div>

          {/* Interactive Accordion list */}
          <div className="space-y-4 shadow-xs border border-slate-200/80 rounded-2xl p-4 sm:p-6 bg-indigo-50/20">
            {FAQS.map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div 
                  key={index}
                  className="bg-white rounded-xl border border-slate-200/70 overflow-hidden shadow-xs transition-shadow hover:shadow-sm"
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                    className="w-full flex items-center justify-between text-left p-4 sm:p-5 font-bold text-brand-primary hover:text-brand-secondary transition-colors text-sm sm:text-base cursor-pointer"
                  >
                    <span>{faq.question}</span>
                    <span className="shrink-0 ml-3 bg-indigo-50 p-1.5 rounded-full border border-indigo-100/65">
                      {isOpen ? <ChevronUp className="w-4 h-4 text-brand-secondary" /> : <ChevronDown className="w-4 h-4 text-brand-secondary" />}
                    </span>
                  </button>

                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.25 }}
                      >
                        <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-700 font-medium leading-relaxed border-t border-slate-100">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

          {/* Real FAQ Schema block mapping */}
          <div className="hidden bg-slate-50 rounded-xl p-4 border border-slate-100 mt-6 text-[10px] text-slate-400">
            {FAQS.map((faq, idx) => (
              <div key={idx} className="mb-4">
                <p className="font-bold">Q: {faq.question}</p>
                <p>A: {faq.answer}</p>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* CONTACT & RESERVATIONS SECTION */}
      <section id="contact" className="py-20 bg-brand-bg scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-stretch">
            
            {/* Location Details & Interactive Google Maps Embed */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
              
              <div className="space-y-4">
                <span className="text-brand-primary text-xs font-mono font-black tracking-widest uppercase bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100">
                  OUR HEADQUARTERS
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-brand-primary tracking-tight">
                  Located in Bhusari Colony, Kothrud
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 font-medium leading-relaxed">
                  Our core training branch is located at Bhusari Colony, Kothrud, Pune, Maharashtra. We also dispatch premier home tuition experts to nearby regions:
                </p>

                {/* Travel Range Tags */}
                <div className="flex flex-wrap gap-2 pt-2 text-brand-primary font-mono font-bold text-[11px]">
                  <span className="bg-indigo-50/55 border border-indigo-100/60 px-3 py-1 rounded-full">📍 Bhusari Colony</span>
                  <span className="bg-indigo-50/55 border border-indigo-100/60 px-3 py-1 rounded-full">📍 Kothrud Central</span>
                  <span className="bg-indigo-50/55 border border-indigo-100/60 px-3 py-1 rounded-full">📍 Karve Nagar</span>
                  <span className="bg-indigo-50/55 border border-indigo-100/60 px-3 py-1 rounded-full">📍 Bavdhan</span>
                  <span className="bg-indigo-50/55 border border-indigo-100/60 px-3 py-1 rounded-full">📍 Warje</span>
                </div>
              </div>

              {/* Real Google Maps Embed representation with customized responsive framing */}
              <div className="w-full h-64 rounded-3xl overflow-hidden shadow-md border-2 border-white relative bg-slate-100 group">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m13!1m3!1d15132.880496884813!2d73.80164624732126!3d18.508216314050212!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bfb9bf4bda7f%3A0x6e7bc6e0a811c05d!2sBhusari%20Colony%2C%20Kothrud%2C%20Pune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1718536102142!5m2!1sen!2sin" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen={true} 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Kothrud Home Tuition Academy location"
                  className="w-full h-full relative z-10"
                />
              </div>

              {/* Direct Address Text block */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-brand-primary flex items-center justify-center shrink-0 border border-indigo-100">
                  <MapPin className="w-5 h-5 text-brand-secondary" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-brand-primary">Bhusari Colony Office Address</h4>
                  <p className="text-[11px] text-slate-650 font-medium leading-relaxed mt-0.5">
                    Sr No 98, Near Bhusari Colony Depot, Paud Road, Kothrud, Pune, Maharashtra, India - 411038
                  </p>
                </div>
              </div>

            </div>

            {/* Structured Leads Inquiry Form */}
            <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-xl flex flex-col justify-between">
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="bg-emerald-100 text-emerald-950 text-[9px] font-black px-2.5 py-1 rounded-full tracking-wider uppercase font-mono">Lead Form</span>
                  <p className="text-xs text-slate-500 font-bold font-mono">⚡ Pre-populates on WhatsApp</p>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-brand-primary">Book Your Free Trial Class Now</h3>
                <p className="text-xs text-slate-600 font-medium">
                  Fill in your details below and your query is instantly organized into a professional draft. Upon clicking submit, you will be automatically redirected to WhatsApp to secure your slot!
                </p>
              </div>

              <form onSubmit={handleFormSubmit} className="space-y-4 mt-6">
                
                {/* Form Row 1 */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Student Name <span className="text-red-500">*</span></label>
                    <input 
                      type="text" 
                      name="studentName"
                      required
                      placeholder="e.g. Advait Kulkarni"
                      value={formData.studentName}
                      onChange={handleInputChange}
                      className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg p-3 text-slate-900 focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Parent Name <span className="text-red-500">*</span></label>
                    <input 
                      type="text" 
                      name="parentName"
                      required
                      placeholder="e.g. Mrs. Smita Kulkarni"
                      value={formData.parentName}
                      onChange={handleInputChange}
                      className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg p-3 text-slate-900 focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Form Row 2 */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Student's Standard/Class <span className="text-red-500">*</span></label>
                    <select 
                      name="standard"
                      value={formData.standard}
                      onChange={handleInputChange}
                      className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg p-3 text-slate-900 focus:outline-none focus:border-brand-primary"
                    >
                      <option value="Nursery / Play-group">Nursery / Play-group</option>
                      <option value="Junior KG">Junior KG</option>
                      <option value="Senior KG">Senior KG</option>
                      <option value="1st Standard">1st Standard</option>
                      <option value="2nd Standard">2nd Standard</option>
                      <option value="3rd Standard">3rd Standard</option>
                      <option value="4th Standard">4th Standard</option>
                      <option value="5th Standard">5th Standard</option>
                      <option value="6th Standard">6th Standard</option>
                      <option value="7th Standard">7th Standard</option>
                      <option value="8th Standard">8th Standard</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Subject Focus <span className="text-red-500">*</span></label>
                    <select 
                      name="subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg p-3 text-slate-900 focus:outline-none focus:border-brand-primary"
                    >
                      <option value="Mathematics">Mathematics</option>
                      <option value="Science / EVS">Science / EVS</option>
                      <option value="English (Academic/Spoken)">English (Academic/Spoken)</option>
                      <option value="Marathi / Hindi">Marathi / Hindi</option>
                      <option value="Phonics Training">Phonics Training</option>
                      <option value="Handwriting Improvement">Handwriting Improvement</option>
                      <option value="Drawing Classes">Drawing Classes</option>
                      <option value="Coding Fundamentals">Coding Fundamentals</option>
                      <option value="All Academic Core Subjects">All Academic Core Subjects</option>
                    </select>
                  </div>
                </div>

                {/* Form Row 3 */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">WhatsApp / Phone Number <span className="text-red-500">*</span></label>
                    <input 
                      type="tel" 
                      name="phoneNumber"
                      required
                      placeholder="e.g. 091724 15302"
                      value={formData.phoneNumber}
                      onChange={handleInputChange}
                      className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg p-3 text-slate-900 focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Tuition Mode Preference <span className="text-red-500">*</span></label>
                    <div className="flex gap-2">
                      <label className="flex-1 bg-slate-50 p-2.5 rounded-lg border border-slate-200 flex items-center gap-2 cursor-pointer text-xs font-medium">
                        <input 
                          type="radio" 
                          name="locationPreference" 
                          value="Home Tuition" 
                          checked={formData.locationPreference === "Home Tuition"}
                          onChange={handleInputChange}
                        />
                        Home Tuition
                      </label>
                      <label className="flex-1 bg-slate-50 p-2.5 rounded-lg border border-slate-200 flex items-center gap-2 cursor-pointer text-xs font-medium">
                        <input 
                          type="radio" 
                          name="locationPreference" 
                          value="Bhusari Colony Batch"
                          checked={formData.locationPreference === "Bhusari Colony Batch"}
                          onChange={handleInputChange}
                        />
                        Batch Class
                      </label>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full text-center bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold p-4 rounded-xl shadow-lg transition-transform active:scale-98 flex items-center justify-center gap-2 text-sm uppercase cursor-pointer"
                  >
                    {formSubmitted ? (
                      <span className="flex items-center gap-2">
                        <span className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
                        Redirecting to WhatsApp Draft...
                      </span>
                    ) : (
                      <>
                        <Send className="w-4 h-4 fill-current" />
                        Submit & Request Free Trial on WhatsApp
                      </>
                    )}
                  </button>
                </div>

              </form>

              {/* Secure Trust Badges block */}
              <div className="border-t border-slate-100 pt-6 mt-6 flex justify-between items-center gap-4 flex-wrap text-[10px] text-slate-400 font-medium">
                <span className="flex items-center gap-1">🔒 Your privacy remains safe with us</span>
                <span className="flex items-center gap-1 text-emerald-600 font-bold">● Free home tutor consultation</span>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-slate-950 text-slate-300 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-b border-slate-800 pb-12">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            
            {/* Column 1: Academy intro */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-lg bg-brand-secondary flex items-center justify-center text-white">
                  <GraduationCap className="w-5 h-5 text-white" />
                </div>
                <span className="font-extrabold text-white text-md tracking-tight font-sans">KOTHRUD TUITION</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Premium, highly trusted educational coaching providing tailored SSC, CBSE, and ICSE home and batch lessons. Over 20 years of proven improvement in scores, phonics competency, and visual writing standards.
              </p>
              <div className="flex items-center gap-3 pt-2">
                <button 
                  onClick={() => handleDirectCTA('default', 'General social inquiry')}
                  className="w-8 h-8 rounded-full bg-slate-900 hover:bg-brand-secondary hover:text-white flex items-center justify-center text-slate-400 transition-colors cursor-pointer"
                  aria-label="Contact social support"
                >
                  <Phone className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Column 2: Subjects & standard links */}
            <div className="space-y-3 col-span-1">
              <h4 className="text-xs font-bold uppercase tracking-wider text-white font-sans">Academic tuition</h4>
              <ul className="space-y-2 text-xs text-slate-400 font-semibold">
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">Nursery & Early Foundation</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">1st Standard Math / EVS classes</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">2nd & 3rd Standard Grammar</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">4th & 5th Standard Languages</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">6th Standard Conceptual Science</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">7th & 8th Standard SSC/CBSE Prep</a></li>
              </ul>
            </div>

            {/* Column 3: Skill links */}
            <div className="space-y-3 col-span-1">
              <h4 className="text-xs font-bold uppercase tracking-wider text-white font-sans">Youth Skill Wings</h4>
              <ul className="space-y-2 text-xs text-slate-400 font-semibold">
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">Interactive Phonics Training</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">Handwriting Speed & cursive drills</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">Kid Drawing & Sketches basics</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">Scratch Coding & computer literacy</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">Weekly public speaking games</a></li>
                <li><a href="#courses" className="hover:text-brand-accent transition-colors">Mental aptitude & puzzles</a></li>
              </ul>
            </div>

            {/* Column 4: Local Contact info */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-white font-sans">Local Pune Support</h4>
              <p className="text-xs text-slate-450 leading-relaxed font-semibold">
                📍 Bhusari Colony Depot road, Kothrud, Pune, Maharashtra, India - 411038
              </p>
              <p className="text-xs text-slate-400 font-bold">
                📱 WhatsApp: <span className="text-brand-accent font-mono">+91 91724 15302</span>
              </p>
              <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg text-[11px] text-slate-350 font-semibold leading-relaxed">
                "Our home tutors actively cover Kothrud, Bhusari Colony Depot, Karve Nagar, Bavdhan, and Warje."
              </div>
            </div>

          </div>

        </div>

        {/* Local SEO keywords bar for ranking in Gemini and general AEO */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-[11px] text-slate-500 leading-relaxed border-b border-slate-800">
          <span className="font-bold text-slate-400 block mb-1">Local SEO & AEO Coverage keywords index:</span>
          <span>home tuition kothrud, home tutor pune, best tuition classes in kothrud, phonics classes pune, handwriting classes kothrud, drawing classes pune, computer classes for kids pune, one to one tuition pune, affordable tuition classes kothrud, home tuition near me, kothrud tutor list, bhusari colony tutoring, karve nagar premium academy, bavdhan standard math tutor, warje primary tutoring services, pune maharashtra india.</span>
        </div>

        {/* Footnote copyright */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>© 2026 Kothrud Home Tuition Academy. All rights reserved.</p>
          <div className="flex gap-4">
            <span className="cursor-pointer hover:text-white" onClick={() => handleDirectCTA('default', 'Enquiring terms')}>Terms of Use</span>
            <span className="cursor-pointer hover:text-white" onClick={() => handleDirectCTA('default', 'Enquiring privacy policies')}>Privacy Policy</span>
          </div>
        </div>

      </footer>

      {/* EXIT INTENT POPUP COMPONENT (FOMO OPTIMIZED DEMO TRIGGER) */}
      <AnimatePresence>
        {showExitPopup && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 font-sans">
            
            {/* Glass Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowExitPopup(false)}
              className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs pointer-events-auto cursor-pointer"
            />

            {/* Premium Animated Popup Content Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative z-10 border border-slate-200/90 flex flex-col gap-6"
            >
              
              {/* Header exit button */}
              <button
                onClick={() => setShowExitPopup(false)}
                className="absolute top-4 right-4 p-1 rounded-full bg-indigo-50 hover:bg-indigo-100/50 text-slate-500 hover:text-brand-primary transition-colors pointer-events-auto cursor-pointer border border-indigo-100/20"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Highlight emblem */}
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-brand-accent flex items-center justify-center border border-amber-100/50 animate-bounce">
                <Sparkles className="w-6 h-6 text-brand-accent" />
              </div>

              <div className="space-y-2">
                <span className="bg-red-50 text-red-700 text-[9px] font-black px-2.5 py-1 rounded-full tracking-wider uppercase font-mono border border-red-100">EXCLUSIVE DEMO OFFER</span>
                <h3 className="text-xl sm:text-2xl font-black text-brand-primary">Wait! Protect Your Child's Future Grade With a Free Demo</h3>
                <p className="text-xs sm:text-sm text-slate-600 font-medium leading-relaxed">
                  Before you exit, secure one remaining slot for a <strong>Free 1-Hour home assessments or center trial</strong> with our senior educator (20+ Years Experience). Absolutely no cost or obligations.
                </p>
              </div>

              {/* Dynamic offer features */}
              <div className="bg-amber-50/40 rounded-2xl p-4 border border-amber-100/60 grid grid-cols-2 gap-3 text-xs font-bold text-slate-800">
                <div className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 stroke-[3]" />
                  <span>Free Math Evaluator</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 stroke-[3]" />
                  <span>Handwriting posture review</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 stroke-[3]" />
                  <span>Phonics level scorecard</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 stroke-[3]" />
                  <span>Syllabus map analysis</span>
                </div>
              </div>

              {/* Instant WhatsApp Conversion button */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => {
                    setShowExitPopup(false);
                    handleDirectCTA('demo');
                  }}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-xl text-xs sm:text-sm text-center shadow-lg cursor-pointer transform transition active:scale-95 flex items-center justify-center gap-2 uppercase tracking-widest"
                >
                  <Phone className="w-4 h-4 fill-current" />
                  Claim My Free Demo (WhatsApp)
                </button>
                <button
                  onClick={() => setShowExitPopup(false)}
                  className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold px-4 py-4 rounded-xl text-xs text-center transition-colors cursor-pointer"
                >
                  No thanks, later
                </button>
              </div>

              <p className="text-center text-[10px] text-slate-500 font-bold">
                ⚡ Only 3 trial demo slots left for Bhusari Colony & Kothrud region this week.
              </p>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

// ChevronRight miniature component for internal scannability cues
function ChevronRightSmall() {
  return (
    <svg className="w-4 h-4 text-slate-400 group-hover:text-brand-secondary group-hover:translate-x-1 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
    </svg>
  );
}
